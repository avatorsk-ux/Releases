const app = document.querySelector("#app");

const state = {
  focus: localDate(),
  view: "day",
  week: null,
  board: null,
  panel: null,
  list: null,
  dicts: false,
  lookups: null,
  form: null,
  busy: [],
  teachersPane: "",
  noticePane: "",
  search: "",
  server: "",
  writable: true,
  version: "",
  online: true,
  serverOpen: false,
  hotTeacher: null,
  hotEvent: null,
  error: "",
  notice: "",
  backupNote: "",
  revision: "",
  license: null,
  excel: null,
  update: null,
  updateTimer: null,
};

function localDate() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}

function addDays(value, count) {
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(year, month - 1, day);
  date.setDate(date.getDate() + count);
  const nextMonth = String(date.getMonth() + 1).padStart(2, "0");
  const nextDay = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${nextMonth}-${nextDay}`;
}

async function loadWeek(date = state.focus) {
  if (date !== state.focus) {
    state.teachersPane = "";
    state.noticePane = "";
  }
  state.focus = date;
  state.error = "";
  try {
    const response = await api(`/api/week?date=${date}`);
    if (!response.ok) throw new Error("fail");
    state.week = await response.json();
  } catch {
    state.week = null;
    state.error = "Календарь на этом компьютере не открылся.";
  }
  render();
}

function api(path, options) {
  return fetch(path, options);
}

function scheduleSearch() {
  if (state.searchTimer) clearTimeout(state.searchTimer);
  const query = state.search.trim();
  if (!query) {
    state.searchHits = null;
    return;
  }
  state.searchTimer = setTimeout(async () => {
    try {
      const response = await api(`/api/search?q=${encodeURIComponent(query)}`);
      if (state.search.trim() !== query) return;
      state.searchHits = await response.json();
    } catch {
      if (state.search.trim() !== query) return;
      state.searchHits = { hits: [] };
    }
    render();
  }, 200);
}

function linkBox() {
  const label = state.online ? "Сеть есть" : "Сети нет";
  return `<div class="link-wrap">
    <button class="link-dot ${state.online ? "" : "off"}" type="button" data-link title="${label}" aria-label="${label}"><i></i></button>
    ${state.serverOpen ? `<div class="server-box">
      <p class="what">Режим</p>
      <div class="choice">
        <button type="button" data-mode="read" class="${state.writable ? "" : "on"}">Чтение</button>
        <button type="button" data-mode="write" class="${state.writable ? "on" : ""}">Запись</button>
      </div>
      <p class="why">${state.writable ? "Можно менять." : "Только смотреть."}</p>
      <form id="server-form">
        <p class="what">Сервер</p>
        <input class="control" name="server" placeholder="http://адрес:4173" value="${escapeHtml(state.server)}">
        <p class="why">Адрес сервера.</p>
        <button class="save" type="submit">Сохранить</button>
      </form>
      <p class="what">Копия</p>
      <p class="why">Файл JSON со всем календарём.</p>
      <div class="choice">
        <button type="button" data-backup-export>Выгрузить</button>
        <button type="button" data-backup-import>Загрузить</button>
      </div>
      ${state.backupNote ? `<p class="why">${escapeHtml(state.backupNote)}</p>` : ""}
      <div class="server-foot">
        <p class="why">Версия ${escapeHtml(state.version || "…")}</p>
        <button class="server-close" type="button" data-close-server>Закрыть</button>
      </div>
    </div>` : ""}
  </div>`;
}

async function ping() {
  const wasOnline = state.online;
  const wasPending = state.pending || 0;
  try {
    const data = await (await api("/api/sync")).json();
    state.online = Boolean(data.online);
    state.pending = data.pending || 0;
    const revision = String(data.revision || "");
    const changed = Boolean(state.revision && revision && state.revision !== revision);
    const cameBack = !wasOnline && state.online;
    const flushed = wasPending > 0 && state.pending === 0;
    if (!state.form) {
      state.revision = revision || state.revision;
      if (state.week && state.online && (cameBack || flushed || changed)) {
        if (state.view === "day") loadWeek(state.focus);
        else loadBoard();
      }
    }
  } catch {
    state.online = false;
  }
  const dot = document.querySelector("[data-link]");
  if (!dot) return;
  dot.classList.toggle("off", !state.online);
  const label = state.online ? "Сеть есть" : "Сети нет";
  dot.title = label;
  dot.setAttribute("aria-label", label);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function minutes(value) {
  if (!value) return null;
  const [hour, minute] = value.split(":").map(Number);
  return hour * 60 + minute;
}

function clock(total) {
  const hour = Math.floor(total / 60);
  const minute = total % 60;
  return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}

function snapMinute(clientY, rect) {
  const ratio = Math.min(1, Math.max(0, (clientY - rect.top) / rect.height));
  const raw = 8 * 60 + ratio * 600;
  return Math.min(18 * 60, Math.max(8 * 60, Math.round(raw / 15) * 15));
}

function boardItem(token) {
  const [type, id] = String(token || "").split(":");
  const list = type === "work" ? state.week?.works : state.week?.events;
  return list?.find((entry) => entry.id === Number(id)) || null;
}

function bindDayBoard() {
  const track = document.querySelector("[data-track]");
  if (!track || !state.writable) return;
  let drag = null;

  const finish = async (event) => {
    if (!drag) return;
    const current = drag;
    drag = null;
    track.classList.remove("armed");
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", finish);
    if (!current.moved) return;
    const item = boardItem(current.token);
    if (!item) return;
    const rect = track.getBoundingClientRect();
    const over = event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
    if (current.mode === "place" && !over) return;
    state.skipOpen = true;
    const point = snapMinute(event.clientY, rect);
    let start = current.originStart;
    let end = current.originEnd;
    if (current.mode === "resize") {
      end = Math.max(start + 15, point);
    } else {
      const duration = Math.max(15, end - start);
      start = Math.min(point - current.grab, 18 * 60 - duration);
      start = Math.max(8 * 60, start);
      end = start + duration;
    }
    await saveTimes(item, clock(start), clock(end));
  };

  const move = (event) => {
    if (!drag) return;
    if (Math.abs(event.clientY - drag.y) > 4 || Math.abs(event.clientX - drag.x) > 4) drag.moved = true;
    if (!drag.moved) return;
    track.classList.add("armed");
    let block = document.querySelector(`.block[data-drag="${drag.token}"]`);
    if (!block && drag.mode === "place") {
      block = track.querySelector(".preview");
      if (!block) {
        block = document.createElement("div");
        block.className = "block event preview";
        block.textContent = boardItem(drag.token)?.title || "Мероприятие";
        track.appendChild(block);
      }
    }
    if (!block) return;
    const rect = track.getBoundingClientRect();
    const point = snapMinute(event.clientY, rect);
    if (drag.mode === "resize") {
      const end = Math.max(drag.originStart + 15, point);
      block.style.top = `${((drag.originStart - 8 * 60) / 600) * 100}%`;
      block.style.height = `${((end - drag.originStart) / 600) * 100}%`;
    } else {
      const duration = Math.max(15, drag.originEnd - drag.originStart);
      let start = Math.min(point - drag.grab, 18 * 60 - duration);
      start = Math.max(8 * 60, start);
      block.style.top = `${((start - 8 * 60) / 600) * 100}%`;
      block.style.height = `${(duration / 600) * 100}%`;
    }
  };

  const begin = (token, mode, event) => {
    const item = boardItem(token);
    if (!item) return;
    const start = minutes(item.start) ?? 9 * 60;
    const end = minutes(item.end) ?? start + 60;
    const rect = track.getBoundingClientRect();
    const point = snapMinute(event.clientY, rect);
    drag = {
      token,
      mode,
      x: event.clientX,
      y: event.clientY,
      moved: false,
      originStart: Math.max(8 * 60, start),
      originEnd: Math.min(18 * 60, Math.max(end, start + 15)),
      grab: mode === "move" && item.start ? point - Math.max(8 * 60, start) : 0,
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", finish);
  };

  document.querySelectorAll("[data-resize]").forEach((grip) => {
    grip.onpointerdown = (event) => {
      event.preventDefault();
      event.stopPropagation();
      begin(grip.dataset.resize, "resize", event);
    };
  });
  document.querySelectorAll("[data-drag]").forEach((node) => {
    node.draggable = true;
    node.ondragstart = (event) => {
      drag = null;
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", finish);
      event.dataTransfer.setData("text/plain", node.dataset.drag);
      event.dataTransfer.effectAllowed = "move";
    };
    node.onpointerdown = (event) => {
      if (event.target.closest("[data-resize]")) return;
      if (event.button !== 0) return;
      begin(node.dataset.drag, node.classList.contains("block") ? "move" : "place", event);
    };
  });
  track.ondragover = (event) => {
    event.preventDefault();
    track.classList.add("armed");
  };
  track.ondragleave = () => track.classList.remove("armed");
  track.ondrop = async (event) => {
    event.preventDefault();
    track.classList.remove("armed");
    state.skipOpen = true;
    const item = boardItem(event.dataTransfer.getData("text/plain"));
    if (!item) return;
    const rect = track.getBoundingClientRect();
    const point = snapMinute(event.clientY, rect);
    const had = minutes(item.start);
    const duration = had != null ? Math.max(15, (minutes(item.end) || had + 60) - had) : 60;
    const start = Math.max(8 * 60, Math.min(point, 18 * 60 - duration));
    await saveTimes(item, clock(start), clock(start + duration));
  };
  track.onclick = (event) => {
    if (state.skipOpen) {
      state.skipOpen = false;
      return;
    }
    if (event.target !== track) return;
    const rect = track.getBoundingClientRect();
    const start = snapMinute(event.clientY, rect);
    const end = Math.min(18 * 60, start + 60);
    openForm({ start: clock(start), end: clock(end) });
  };
}

async function saveTimes(item, start, end) {
  const isWork = item.type === "work";
  const payload = {
    title: item.title,
    date: item.date,
    endDate: item.endDate || "",
    start,
    end,
    allDay: false,
    note: item.note || "",
    classIds: item.classIds || [],
    teacherIds: item.teacherIds || [],
    teacherId: (item.teacherIds || [])[0] || null,
    kind: item.detail || "",
    wholeSchool: item.audience === "вся школа",
    audience: item.audience === "вся школа" ? "вся школа" : "",
    eventKindId: item.kindId || null,
  };
  try {
    const response = await api(isWork ? `/api/works/${item.id}` : `/api/events/${item.id}`, {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      state.notice = "Время не сохранилось. Запись осталась как была.";
      await loadWeek(item.date);
      return;
    }
    state.notice = "";
    await loadWeek(item.date);
  } catch {
    state.notice = "Сеть пропала, время не сохранилось.";
    render();
  }
}

function placeBlocks(items) {
  const placed = items
    .filter((item) => item.start)
    .map((item) => {
      const start = Math.max(8 * 60, minutes(item.start));
      const end = Math.min(18 * 60, minutes(item.end) || start + 45);
      return { ...item, top: ((start - 8 * 60) / 600) * 100, height: Math.max(((end - start) / 600) * 100, 8), column: 0, columns: 1 };
    });
  const seen = new Set();
  const hits = (left, right) => left.top < right.top + right.height && right.top < left.top + left.height;
  for (const item of placed) {
    if (seen.has(item)) continue;
    const cluster = [];
    const stack = [item];
    while (stack.length) {
      const current = stack.pop();
      if (seen.has(current)) continue;
      seen.add(current);
      cluster.push(current);
      for (const other of placed) {
        if (!seen.has(other) && hits(current, other)) stack.push(other);
      }
    }
    if (cluster.length > 1) {
      cluster.sort((left, right) => left.top - right.top);
      cluster.forEach((entry, index) => {
        entry.columns = 2;
        entry.column = index % 2;
      });
    }
  }
  return placed;
}

function readForm() {
  const form = document.querySelector("#event-form");
  if (!form || !state.form) return;
  const data = Object.fromEntries(new FormData(form));
  state.form = {
    ...state.form,
    ...data,
    query: document.querySelector("#teacher-search")?.value ?? state.form.query,
  };
}

function licenseBlocks() {
  return Boolean(state.license && (state.license.state === "denied" || state.license.state === "expired"));
}

function licenseScreen() {
  const message = state.license?.error || "Программа остановлена.";
  return `<div class="license-gate">
    <img class="mark" src="/mark.svg" alt="">
    <h1>Календарь</h1>
    <p>${escapeHtml(message)}</p>
    <button class="primary" type="button" id="license-retry">Повторить</button>
  </div>`;
}

function render() {
  if (licenseBlocks()) {
    app.innerHTML = licenseScreen();
    bindLicense();
    return;
  }
  readForm();
  const saved = document.activeElement;
  const selection = saved?.id ? saved.selectionStart : null;
  app.innerHTML = `${linkBox()}${state.week ? page(state.week) : `<div class="screen"><p class="banner">${escapeHtml(state.error || "Открываю календарь…")}</p>${excelBox()}${imprint()}</div>`}${updateBox()}`;
  bind();
  bindUpdate();
  bindExcel();
  if (saved?.id) {
    const next = document.getElementById(saved.id);
    if (next) {
      next.focus();
      if (selection != null && next.setSelectionRange) next.setSelectionRange(selection, selection);
    }
  }
}

function found(query, ...parts) {
  if (!query) return true;
  const hay = parts.join(" ").toLowerCase().replace(/ё/g, "е");
  return hay.includes(query.replace(/ё/g, "е"));
}

function page(week) {
  const query = state.search.trim().toLowerCase();
  const busyAll = week.teachers.filter((teacher) => teacher.state !== "free");
  const freeAll = week.teachers.filter((teacher) => teacher.state === "free");
  const busy = busyAll.filter((teacher) => found(query, teacher.name, teacher.label, teacher.title));
  const free = freeAll.filter((teacher) => found(query, teacher.name, teacher.label, teacher.title));
  const todo = week.todo.filter((row) => found(query, row.title, row.why, row.when));
  const clashes = week.clashes.filter((row) => found(query, row.title, row.eventTitle, row.workTitle, row.workMeta, row.why, row.when));
  const otherDays = week.days.filter((day) => day.date !== week.focus && found(query, day.line, day.sub, day.dow, ...(day.items || []).flatMap((item) => [item.title, item.time])));
  return `
    <div class="screen">
      <header>
        <div class="brand-row">
          <img class="mark" src="/mark.svg" alt="">
          <div class="brand-block">
            <p class="school">Азъ Буки Веди · Ростов-на-Дону</p>
            <h1 class="date">${escapeHtml(state.view === "day" ? week.full : state.board?.label || week.full)}</h1>
            <div class="context">${state.view === "day" ? week.periods.map((period) => `<span class="chip">${escapeHtml(period.name)}</span>`).join("") || `<span class="chip">Вне учебного периода</span>` : ""}</div>
          </div>
        </div>
        <div class="header-actions">
          <nav class="quiet">
            ${["day", "month", "semester", "year"].map((view) => `<button type="button" class="${state.view === view ? "on" : ""}" data-view="${view}">${{ day: "День", month: "Месяц", semester: "Семестр", year: "Год" }[view]}</button>`).join("")}
          </nav>
          <button class="arrow" type="button" data-move="-1">←</button>
          <button class="today-link" type="button" data-today>Сегодня</button>
          <button class="arrow" type="button" data-move="1">→</button>
          <div class="dicts">
            <button type="button" data-dicts class="${state.dicts ? "on" : ""}">Справочники</button>
            ${state.dicts ? `<div class="dict-pop"><button type="button" data-panel="teachers">Учителя</button><button type="button" data-panel="classes">Классы</button><button type="button" data-panel="kinds">Вид контрольной</button><button type="button" data-panel="subjects">Предметы</button></div>` : ""}
          </div>
          ${state.writable ? `<button class="primary" type="button" data-new>Мероприятие</button>` : ""}
        </div>
      </header>
      <label class="search-bar">
        <span>Поиск</span>
        <input class="control" id="dash-search" placeholder="Учитель, мероприятие, класс, предмет" value="${escapeHtml(state.search)}">
      </label>
      ${state.notice ? `<p class="banner">${escapeHtml(state.notice)}</p>` : ""}
      ${query ? searchListHtml() : (state.view === "day" ? dayLayout(week, query, busy, free, busyAll, freeAll, todo, clashes, otherDays) : boardHtml())}
      ${state.form ? formHtml() : ""}
      ${state.panel ? panelHtml(week) : ""}
      ${excelBox()}
      ${imprint()}
    </div>
  `;
}

function imprint() {
  return `<button class="imprint" type="button" data-site>https://proxip.ru</button>`;
}

function excelBox() {
  if (!state.excel) return "";
  const folder = state.excel.folder || "";
  const ready = Boolean(folder);
  const status = state.excel.error
    ? `<p class="save-status error">${escapeHtml(state.excel.error)}</p>`
    : state.excel.name
      ? `<p class="save-status ok">Файл сохранён: ${escapeHtml(state.excel.name)}</p>`
      : `<p class="save-status">Выберите папку и сохраните файл</p>`;
  return `<div class="overlay save-overlay" data-close-save><div class="save-box" data-stop>
    <p class="what">Сохранить в Excel</p>
    <label class="field">Папка
      <input class="control" id="excel-path" value="${escapeHtml(folder)}" placeholder="D:\\Документы\\Календарь">
    </label>
    <div class="actions">
      <button class="ghost" type="button" data-pick-folder>Выбрать папку</button>
      <button class="ghost" type="button" data-open-folder ${ready ? "" : "disabled"}>Открыть папку</button>
    </div>
    <button class="primary" type="button" data-save-excel ${ready ? "" : "disabled"}>Сохранить файл</button>
    ${status}
  </div></div>`;
}

function updateBox() {
  const update = state.update;
  if (!update || update.dismissed) return "";
  const downloading = update.status === "downloading" || update.status === "applying";
  const ready = update.status === "ready";
  const error = update.status === "error";
  const percent = Math.max(0, Math.min(100, Number(update.percent || 0)));
  return `<div class="overlay update-overlay"><div class="update-box">
    <img class="mark" src="/mark.svg" alt="">
    <h2>Доступно обновление</h2>
    <p class="update-ver">Версия ${escapeHtml(update.version || "")} <span>сейчас ${escapeHtml(update.current || "")}</span></p>
    ${update.notes ? `<p class="update-notes">${escapeHtml(update.notes)}</p>` : ""}
    ${(downloading || ready || error) ? `<div class="progress"><i style="width:${percent}%"></i></div>
      <p class="update-msg">${escapeHtml(update.message || (ready ? "Готово к установке" : ""))}</p>` : ""}
    <div class="actions">
      ${downloading
        ? `<button class="primary" type="button" disabled>Перезапуск сам, после загрузки</button>`
        : `<button class="primary" type="button" data-update-start>Обновить</button>`}
      <button class="ghost" type="button" data-update-later ${downloading ? "disabled" : ""}>Позже</button>
    </div>
  </div></div>`;
}

function dayLayout(week, query, busy, free, busyAll, freeAll, todo, clashes, otherDays) {
  return `<div class="layout-b">
    <div class="today-col">
      <section class="today-hero">
        <p class="kicker">${week.isToday ? "Сегодня" : "Выбранный день"} · ${escapeHtml(week.weekLabel)}</p>
        <h2 class="hero-date">${escapeHtml(week.hero)}</h2>
        <p class="hero-sub">${state.writable ? "Перетащите мероприятие на время и потяните за нижний край, чтобы задать длительность" : "Сейчас только просмотр"}</p>
        ${dayCards(week, query)}
        ${scaleHtml(week, query)}
      </section>
    </div>
    <div class="side-col">
      <div class="side-top">
        <section class="other-days">
          <h2>Остальные дни</h2>
          ${otherDays.map((day) => dayButton(day)).join("") || `<p class="calm">Ничего не нашли</p>`}
        </section>
        <div class="side-band">
          <div class="notice-pair${state.noticePane ? " has-open" : ""}">
            ${noticeCard("todo", "Необходимо", "дописать", todo, query ? "Ничего не нашли" : "Всё заполнено", true)}
            ${noticeCard("clash", "В день", "совпало", clashes, query ? "Ничего не нашли" : "Совпадений нет", false)}
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

function teachersCard(busy, free, busyAll, freeAll, query) {
  const pane = state.teachersPane;
  const people = pane === "free" ? free : pane === "busy" ? busy : [];
  const rows = people.map((teacher) => {
    const hot = state.hotTeacher === teacher.id ? " hot" : "";
    if (pane === "free") {
      return `<li><button class="free${hot}" type="button" data-teacher="${teacher.id}"><span class="what">${escapeHtml(teacher.name)}</span></button></li>`;
    }
    const place = teacher.title || "Занят";
    const time = teacher.label || "без времени";
    return `<li><button class="${teacher.state}${hot}" type="button" data-teacher="${teacher.id}">
      <span class="what">${escapeHtml(teacher.name)}</span>
      <span class="why">${escapeHtml(place)} · ${escapeHtml(time)}</span>
    </button></li>`;
  }).join("");
  const body = pane
    ? rows
      ? `<ol>${rows}</ol>`
      : `<p class="calm">${query ? "Никого не нашли" : "Никого"}</p>`
    : "";
  return `<section class="teachers-drawer ${pane ? "open" : ""}">
    <div class="teachers-fold">
      <span class="fold-title">Учителя в этот день</span>
      <span class="fold-counts">
        <button class="fold-count free ${pane === "free" ? "on" : ""}" type="button" data-teachers="free"><b>${freeAll.length}</b> свободно</button>
        <button class="fold-count busy ${pane === "busy" ? "on" : ""}" type="button" data-teachers="busy"><b>${busyAll.length}</b> занято</button>
      </span>
    </div>
    ${body}
  </section>`;
}

function searchListHtml() {
  if (!state.searchHits) return `<p class="calm">Ищу…</p>`;
  const hits = state.searchHits.hits || [];
  if (!hits.length) return `<p class="calm">Ничего не нашли</p>`;
  return `<div class="search-hits">${hits.map((hit) => `<button class="card ${hit.type === "work" ? "test" : "event"}" type="button" data-date="${hit.date}">
    <p class="kind">${escapeHtml(hit.kind)} · ${escapeHtml(hit.when)}</p>
    <h3>${escapeHtml(hit.title)}</h3>
    <p class="who">${escapeHtml(hit.teacher || "Ответственный не назначен")}</p>
  </button>`).join("")}</div>`;
}

function boardHtml() {
  const board = state.board;
  if (!board) return `<p class="calm">Открываю доску…</p>`;
  const weekNames = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"];
  return `<div class="boards">${board.months.map((month) => `
    <section class="month-block">
      <div class="month-head">
        <h2>${escapeHtml(month.label)}</h2>
        <button class="excel" type="button" data-excel>Excel</button>
      </div>
      <div class="board-grid">
        ${weekNames.map((name) => `<span class="dow-name">${name}</span>`).join("")}
        ${Array.from({ length: month.offset }, () => `<span></span>`).join("")}
        ${month.days.map((day) => cellHtml(day)).join("")}
      </div>
    </section>`).join("") || `<p class="calm">В этом отрезке записей нет</p>`}</div>`;
}

function personChip(teacher) {
  const extra = teacher.state === "busy" ? ` ${teacher.label || ""}` : teacher.state === "untimed" ? " без времени" : "";
  const hot = state.hotTeacher === teacher.id ? " hot" : "";
  return `<button class="chip-person ${teacher.state}${hot}" type="button" data-teacher="${teacher.id}" data-event="${teacher.eventId || ""}">${escapeHtml(teacher.name)}${escapeHtml(extra)}</button>`;
}

function dayCards(week, query) {
  const items = [...week.works, ...week.events].filter((item) => found(query, item.title, item.meta, item.detail, item.teacher, item.audience, item.note));
  if (!items.length && !query) {
    return `<button class="card event" type="button" data-new><p class="kind">Мероприятие</p><h3>Мероприятия нет</h3><p class="detail">День свободен для нового</p></button>`;
  }
  if (!items.length) return `<p class="calm">В этот день по поиску ничего нет</p>`;
  return `<div class="untimed">${items.map((item) => cardHtml(item, item.type === "work" ? "test" : "event", item.type === "work" ? "Контрольная" : "Мероприятие")).join("")}</div>`;
}

function bitsHtml(bits) {
  return (bits || []).map((bit, index) => `${index ? " · " : ""}<span class="${bit.kind ? `tag tag-${bit.kind}` : ""}">${escapeHtml(bit.text)}</span>`).join("");
}

function cardHtml(item, kind, label) {
  const hot = item.teacherId && state.hotTeacher === item.teacherId ? " hot" : "";
  const time = item.allDay
    ? "весь день"
    : item.start
      ? `${item.start}${item.end ? `–${item.end}` : ""}`
      : "Время не назначено";
  const who = item.teacher || "Ответственный не назначен";
  const whoClass = item.teacher ? "" : "tag tag-who";
  const timeClass = item.allDay || item.start ? "" : "tag tag-time";
  const rest = [
    item.type === "work" ? item.meta : item.audience,
    item.detail,
    item.note,
  ].filter(Boolean).join(" · ");
  return `<button class="card ${kind}${hot}" type="button" data-open="${item.type}:${item.id}" data-teacher="${item.teacherId || ""}" ${state.writable ? `data-drag="${item.type}:${item.id}"` : ""}>
    <p class="kind">${label}</p>
    <h3>${escapeHtml(item.title)}</h3>
    ${who ? `<p class="who ${whoClass}">${escapeHtml(who)}</p>` : ""}
    <p class="detail"><span class="${timeClass}">${escapeHtml(time)}</span>${rest ? ` · ${escapeHtml(rest)}` : ""}</p>
  </button>`;
}

function scaleHtml(week, query) {
  const blocks = placeBlocks([...week.works, ...week.events].filter((item) => found(query, item.title, item.meta, item.detail, item.teacher, item.audience)));
  const hours = Array.from({ length: 10 }, (_, index) => `<span>${String(8 + index).padStart(2, "0")}:00</span>`).join("");
  const bars = blocks.map((block) => {
    const hot = (block.teacherId && state.hotTeacher === block.teacherId) || state.hotEvent === block.id ? " hot" : "";
    const width = block.columns === 2 ? "calc(50% - 12px)" : "calc(100% - 16px)";
    const left = block.columns === 2 && block.column ? "calc(50% + 4px)" : "8px";
    const label = block.type === "work" ? "Контрольная" : "Мероприятие";
    const kind = block.type === "work" ? "test" : "event";
    const who = block.teacher || "Ответственный не назначен";
    const whoHtml = `<span class="${block.teacher ? "" : "tag tag-who"}">${escapeHtml(who)}</span>`;
    const extra = [block.type === "work" ? block.meta : "", block.detail].filter(Boolean).join(" · ");
    const body = block.height <= 10
      ? `<span class="bar-line"><span class="kind">${label}</span>${escapeHtml(block.title)}</span>`
      : `<p class="kind">${label}</p><h3>${escapeHtml(block.title)}</h3>${who ? `<p class="who">${whoHtml}</p>` : ""}${extra ? `<p class="detail">${escapeHtml(extra)}</p>` : ""}`;
    return `<button class="block ${kind}${hot}" type="button" data-open="${block.type}:${block.id}" data-teacher="${block.teacherId || ""}" ${state.writable ? `data-drag="${block.type}:${block.id}"` : ""}
      style="top:${block.top}%;height:${block.height}%;left:${left};width:${width}">
      ${body}
      ${state.writable ? `<i class="grip" data-resize="${block.type}:${block.id}"></i>` : ""}
    </button>`;
  }).join("");
  return `<div class="scale"><div class="hours">${hours}</div><div class="track" data-track>${bars}</div></div>`;
}

function noticeCard(kind, title, word, rows, empty, editable) {
  const open = state.noticePane === kind;
  const list = rows.map((row) => {
    const pair = row.eventTitle
      ? `<span class="pair">
          <span class="pair-line event"><i>Мероприятие</i><b>${escapeHtml(row.eventTitle)}</b></span>
          <span class="pair-line work"><i>Контрольная</i><b>${escapeHtml(row.workTitle)}</b>${row.workMeta ? `<em>${escapeHtml(row.workMeta)}</em>` : ""}</span>
        </span>`
      : `<span class="what">${escapeHtml(row.label || row.title)}</span>
         <span class="why">${row.bits ? bitsHtml(row.bits) : escapeHtml(row.why || "")}</span>`;
    return `<li><button class="${editable ? (row.type === "work" ? "work" : "event") : ""}" type="button" ${editable ? `data-edit="${row.type || "event"}:${row.id}"` : `data-jump="${row.date}"`}>
      <span class="when">${escapeHtml(row.when)}</span>
      ${pair}
    </button></li>`;
  }).join("");
  const body = open ? (list ? `<ol>${list}</ol>` : `<p class="calm">${empty}</p>`) : "";
  return `<section class="teachers-drawer notice-drawer ${open ? "open" : ""}">
    <div class="teachers-fold notice-fold">
      <span class="fold-title">${title}</span>
      <button class="notice-plaque ${kind} ${open ? "on" : ""}" type="button" data-notice="${kind}">
        <b>${rows.length}</b>
        <span>${word}</span>
      </button>
    </div>
    ${body}
  </section>`;
}

function cellHtml(day) {
  const kind = day.marks.includes("event") && day.marks.includes("test")
    ? "both-day"
    : day.marks.includes("event")
      ? "event-day"
      : day.marks.includes("test")
        ? "test-day"
        : "";
  const items = (day.items || []).map((item) => `<span class="cell-item ${item.kind}">
      <b>${escapeHtml(item.title)}</b>
      ${item.time ? `<i>${escapeHtml(item.time)}</i>` : ""}
    </span>`).join("");
  return `<button class="cell ${kind}" type="button" data-date="${day.date}">
    <span class="num">${day.dayNum}</span>
    <span class="cell-list">${items || `<span class="cell-empty">Пока пусто</span>`}</span>
  </button>`;
}

function dayButton(day) {
  const kind = day.marks.includes("event") && day.marks.includes("test")
    ? "both-day"
    : day.marks.includes("event")
      ? "event-day"
      : day.marks.includes("test")
        ? "test-day"
        : "";
  const dots = day.marks.map((mark) => `<i class="dot ${mark}"></i>`).join("");
  const items = (day.items || []).map((item) => `${escapeHtml(item.title)}${item.time ? ` · ${escapeHtml(item.time)}` : ""}`).join("<br>");
  return `<button class="mini ${kind}" type="button" data-date="${day.date}">
    <div><p class="dow">${day.dow}</p><p class="num">${day.dayNum}</p></div>
    <div><p class="mini-list">${items || escapeHtml(day.line || "Пока пусто")}</p></div>
    <span class="marks">${dots}</span>
  </button>`;
}

function formHtml() {
  const form = state.form;
  const allDay = Boolean(form.allDay);
  return `<div class="overlay">
    <form class="modal" id="event-form">
      <div class="modal-head">
        <h2>${form.id ? (form.kind === "work" ? "Контрольная" : "Мероприятие") : "Новая запись"}</h2>
        <button class="close" type="button" data-close>Закрыть</button>
      </div>
      ${form.id ? "" : `<div class="choice">
        <button type="button" data-kind="event" class="${form.kind === "work" ? "" : "on"}">Мероприятие</button>
        <button type="button" data-kind="work" class="${form.kind === "work" ? "on" : ""}">Контрольная</button>
      </div>`}
      <div class="grid-2">
        <label class="field">Дата<input class="control" id="field-date" name="date" type="date" value="${escapeHtml(form.date)}" required></label>
        ${form.kind === "work" ? "<span></span>" : `<label class="field">Дата окончания<input class="control" name="endDate" type="date" value="${escapeHtml(form.endDate || "")}"></label>`}
      </div>
      <div class="time-row">
        <label class="field">Время начала<input class="control" id="field-start" name="start" type="time" value="${escapeHtml(form.start || "")}" ${allDay ? "disabled" : ""}></label>
        <label class="field">Время окончания<input class="control" name="end" type="time" value="${escapeHtml(form.end || "")}" ${allDay ? "disabled" : ""}></label>
        <label class="all-day"><input type="checkbox" name="allDay" ${allDay ? "checked" : ""}> Весь день</label>
      </div>
      ${form.kind === "work" ? subjectField(form) : `<label class="field">Название<input class="control" id="field-title" name="title" value="${escapeHtml(form.title || "")}" required autofocus></label>`}
      ${form.kind === "work" ? workFields(form) : eventFields(form)}
      <label class="field">Пометка<input class="control" name="note" value="${escapeHtml(form.note || "")}"></label>
      <div class="modal-actions">
        ${form.id ? `<button class="danger" type="button" data-delete>Удалить</button>` : "<span></span>"}
        <button class="save" type="submit">Сохранить</button>
      </div>
    </form>
  </div>`;
}

function eventFields(form) {
  return `${audienceChips(form)}
    ${teacherChips(form, "Ответственные")}`;
}

function subjectField(form) {
  const subjects = state.lookups?.subjects || [];
  const known = subjects.some((item) => item.name === form.title);
  const extra = form.title && !known ? `<option value="${escapeHtml(form.title)}" selected>${escapeHtml(form.title)}</option>` : "";
  return `<label class="field">Предмет
      <select class="control" id="field-title" name="title" required>
        <option value="">Выберите предмет</option>
        ${extra}
        ${subjects.map((item) => `<option value="${escapeHtml(item.name)}" ${item.name === form.title ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("")}
      </select>
    </label>`;
}

function workFields(form) {
  const lookups = state.lookups || { classes: [], kinds: [] };
  return `<label class="field">Вид
      <select class="control" name="kind">
        <option value="">Не указан</option>
        ${lookups.kinds.map((kind) => `<option value="${escapeHtml(kind.name)}" ${kind.name === form.kindName ? "selected" : ""}>${escapeHtml(kind.name)}</option>`).join("")}
      </select>
    </label>
    ${teacherChips(form, "Преподаватели")}
    ${classChips(form)}`;
}

function classList() {
  return (state.lookups?.classes || []).map((item) => {
    const parsed = Number(String(item.name).match(/^\d+/)?.[0]);
    const grade = item.grade ?? (Number.isFinite(parsed) ? parsed : null);
    return { ...item, grade };
  });
}

function classSummary(form) {
  if (form.wholeSchool || form.audience === "вся школа") return "Вся школа";
  const selected = new Set((form.classIds || []).map(String));
  const names = classList().filter((item) => selected.has(String(item.id))).map((item) => item.name);
  return names.length ? names.join(", ") : "не выбрано";
}

function teacherSummary(form) {
  const selected = new Set((form.teacherIds || []).map(String));
  const names = (state.busy || []).filter((teacher) => selected.has(String(teacher.id))).map((teacher) => teacher.name);
  return names.length ? names.join(", ") : "не выбрано";
}

function foldBlock(key, title, summary, body) {
  const open = Boolean(state.form?.[key]);
  return `<div class="fold-field ${open ? "open" : ""}">
    <button type="button" class="fold-head" data-fold="${key}">
      <span>${title}</span>
      <em>${escapeHtml(summary)}</em>
      <i>${open ? "свернуть" : "открыть"}</i>
    </button>
    ${open ? body : ""}
  </div>`;
}

function gradeButtons(form) {
  const classes = classList();
  const selected = new Set((form.classIds || []).map(String));
  const whole = Boolean(form.wholeSchool) || form.audience === "вся школа";
  const grades = [...new Set(classes.map((item) => item.grade).filter((grade) => grade != null))].sort((left, right) => left - right);
  if (!grades.length) return "";
  return `<div class="chip-pick grades">
    ${grades.map((grade) => {
      const ofGrade = classes.filter((item) => item.grade === grade);
      const on = !whole && ofGrade.length && ofGrade.every((item) => selected.has(String(item.id)));
      return `<button type="button" class="pick grade ${on ? "on" : ""}" data-grade="${grade}">все ${grade}</button>`;
    }).join("")}
  </div>`;
}

function audienceChips(form) {
  const whole = Boolean(form.wholeSchool) || form.audience === "вся школа";
  const body = `<div class="chip-pick">
      <button type="button" class="pick ${whole ? "on" : ""}" data-whole-school>Вся школа</button>
    </div>
    ${gradeButtons(form)}
    <div class="chip-pick">
      ${classList().map((item) => {
        const on = !whole && (form.classIds || []).map(String).includes(String(item.id));
        return `<button type="button" class="pick ${on ? "on" : ""}" data-class-id="${item.id}">${escapeHtml(item.name)}</button>`;
      }).join("") || `<span class="calm">Сначала добавьте классы в справочник</span>`}
    </div>`;
  return foldBlock("foldWho", "Для кого", classSummary(form), body);
}

function classChips(form) {
  const selected = new Set((form.classIds || []).map(String));
  const body = `${gradeButtons(form)}
    <div class="chip-pick">
      ${classList().map((item) => `<button type="button" class="pick ${selected.has(String(item.id)) ? "on" : ""}" data-class-id="${item.id}">${escapeHtml(item.name)}</button>`).join("") || `<span class="calm">Сначала добавьте классы в справочник</span>`}
    </div>`;
  return foldBlock("foldWho", "Классы", classSummary(form), body);
}

function teacherChips(form, label) {
  const selected = new Set((form.teacherIds || []).map(String));
  const rows = state.busy.length ? state.busy : [];
  const body = `<div class="chip-pick teachers">
      ${rows.map((teacher) => {
        const tag = teacher.state === "busy" ? "занят" : teacher.state === "untimed" ? "без времени" : "свободен";
        return `<button type="button" class="pick ${selected.has(String(teacher.id)) ? "on" : ""} ${teacher.state}" data-teacher-id="${teacher.id}">
          ${escapeHtml(teacher.name)}<em>${tag}</em>
        </button>`;
      }).join("") || `<span class="calm">Список учителей пуст</span>`}
    </div>`;
  return foldBlock("foldTeachers", label, teacherSummary(form), body);
}

function panelHtml(week) {
  if (state.panel === "teachers") return teachersHtml(week);
  if (state.panel === "classes") return classesHtml();
  if (state.panel === "kinds") return namedDictHtml("Вид контрольной", "kinds", state.lookups?.kinds);
  if (state.panel === "subjects") return namedDictHtml("Предметы", "subjects", state.lookups?.subjects);
  if (state.panel === "events" || state.panel === "works") return listHtml();
  return "";
}

function listHtml() {
  const list = state.list || { title: "", rows: [] };
  return `<div class="overlay"><div class="modal">
    <div class="modal-head"><h2>${escapeHtml(list.title || "")}</h2><button class="close" type="button" data-close>Закрыть</button></div>
    <div class="list">${(list.rows || []).map((row) => `<button type="button" data-date="${row.date}">${escapeHtml(row.date.slice(8))} ${escapeHtml(row.title)} · ${escapeHtml(row.meta || "")}</button>`).join("") || `<p class="calm">В этом отрезке пусто</p>`}</div>
  </div></div>`;
}

function monthHtml() {
  const offset = (new Date(state.month.start + "T12:00:00").getDay() + 6) % 7;
  const blanks = Array.from({ length: offset }, () => `<span></span>`).join("");
  const cells = state.month.days.map((day) => {
    const dots = day.marks.map((mark) => `<i class="dot ${mark}"></i>`).join("");
    return `<button type="button" data-date="${day.date}">${Number(day.date.slice(8))}<span class="marks">${dots}</span></button>`;
  }).join("");
  return `<div class="overlay"><div class="modal wide">
    <div class="modal-head"><h2>${escapeHtml(state.month.label)}</h2><button class="close" type="button" data-close>Закрыть</button></div>
    <div class="month-grid">${blanks}${cells}</div>
  </div></div>`;
}

function dictActions(kind, id) {
  if (!state.writable) return "";
  return `<span class="dict-actions"><button class="edit" type="button" data-edit-dict="${kind}:${id}">Изменить</button><button class="drop" type="button" data-delete-dict="${kind}:${id}">Удалить</button></span>`;
}

function teachersHtml(week) {
  const query = (state.teacherQuery || "").trim().toLowerCase();
  const rows = week.teachers.filter((teacher) => teacher.name.toLowerCase().includes(query));
  const draft = state.dictDraft?.kind === "teachers" ? state.dictDraft : {};
  return `<div class="overlay"><form class="modal" id="teacher-form">
    <div class="modal-head"><h2>Учителя</h2><button class="close" type="button" data-close>Закрыть</button></div>
    <input class="control" id="people-search" placeholder="Поиск по фамилии" value="${escapeHtml(state.teacherQuery || "")}">
    ${state.writable ? `<div class="grid-2">
      <input class="control" name="lastName" placeholder="Фамилия" value="${escapeHtml(draft.lastName || "")}" required>
      <input class="control" name="firstName" placeholder="Имя" value="${escapeHtml(draft.firstName || "")}">
      <input class="control" name="patronymic" placeholder="Отчество" value="${escapeHtml(draft.patronymic || "")}">
    </div>
    <div class="dict-save">
      <button class="save" type="submit">${draft.id ? "Сохранить" : "Добавить"}</button>
      ${draft.id ? `<button class="ghost" type="button" data-cancel-edit>Отмена</button>` : ""}
    </div>` : ""}
    <div class="list">${rows.map((teacher) => `<div class="dict-row"><span>${escapeHtml(teacher.name)}</span>${dictActions("teachers", teacher.id)}</div>`).join("")}</div>
  </form></div>`;
}

function classesHtml() {
  const classes = state.lookups?.classes || [];
  const draft = state.dictDraft?.kind === "classes" ? state.dictDraft : {};
  return `<div class="overlay"><form class="modal" id="class-form">
    <div class="modal-head"><h2>Классы</h2><button class="close" type="button" data-close>Закрыть</button></div>
    ${state.writable ? `<input class="control" name="name" placeholder="Например, 7Г" value="${escapeHtml(draft.name || "")}" required>
    <div class="dict-save">
      <button class="save" type="submit">${draft.id ? "Сохранить" : "Добавить"}</button>
      ${draft.id ? `<button class="ghost" type="button" data-cancel-edit>Отмена</button>` : ""}
    </div>` : ""}
    <div class="list">${classes.map((item) => `<div class="dict-row"><span>${escapeHtml(item.name)}</span>${dictActions("classes", item.id)}</div>`).join("")}</div>
  </form></div>`;
}

function namedDictHtml(title, kind, rows) {
  const draft = state.dictDraft?.kind === kind ? state.dictDraft : {};
  return `<div class="overlay"><form class="modal" id="named-form" data-named="${kind}">
    <div class="modal-head"><h2>${title}</h2><button class="close" type="button" data-close>Закрыть</button></div>
    ${state.writable ? `<input class="control" name="name" placeholder="Название" value="${escapeHtml(draft.name || "")}" required>
    <div class="dict-save">
      <button class="save" type="submit">${draft.id ? "Сохранить" : "Добавить"}</button>
      ${draft.id ? `<button class="ghost" type="button" data-cancel-edit>Отмена</button>` : ""}
    </div>` : ""}
    <div class="list">${(rows || []).map((item) => `<div class="dict-row"><span>${escapeHtml(item.name)}</span>${dictActions(kind, item.id)}</div>`).join("") || `<p class="calm">Пока пусто</p>`}</div>
  </form></div>`;
}

function worksHtml(week) {
  const rows = week.days.flatMap((day) => day.date === week.focus ? week.works : []);
  const all = week.works;
  return `<div class="overlay"><div class="modal">
    <div class="modal-head"><h2>Контрольные ${escapeHtml(week.hero)}</h2><button class="close" type="button" data-close>Закрыть</button></div>
    <div class="list">${all.map((work) => `<div>${escapeHtml(work.title)} · ${escapeHtml(work.meta || "класс не из справочника")} · ${escapeHtml(work.detail)}</div>`).join("") || `<p class="calm">В этот день контрольных нет</p>`}</div>
  </div></div>`;
}

function highlightTeacher(id) {
  document.querySelectorAll("[data-teacher]").forEach((element) => {
    element.classList.toggle("hot", Boolean(id) && element.dataset.teacher === String(id));
  });
}

function bind() {
  document.querySelector("[data-link]")?.addEventListener("click", () => openSettings());
  document.querySelectorAll("[data-excel]").forEach((button) => {
    button.onclick = () => {
      state.excel = { folder: state.excel?.folder || "", name: "", error: "" };
      render();
    };
  });
  document.querySelector("[data-site]")?.addEventListener("click", () => {
    fetch("/api/open-site", { method: "POST" });
  });
  document.querySelector("[data-close-server]")?.addEventListener("click", () => {
    state.serverOpen = false;
    render();
  });
  document.querySelectorAll("[data-delete-teacher]").forEach((button) => {
    button.onclick = () => removeDict("teachers", button.dataset.deleteTeacher);
  });
  document.querySelectorAll("[data-delete-class]").forEach((button) => {
    button.onclick = () => removeDict("classes", button.dataset.deleteClass);
  });
  document.querySelectorAll("[data-mode]").forEach((button) => {
    button.onclick = () => setWritable(button.dataset.mode === "write");
  });
  document.querySelector("[data-backup-export]")?.addEventListener("click", () => exportBackup());
  document.querySelector("[data-backup-import]")?.addEventListener("click", () => importBackup());
  document.querySelector("#server-form")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    state.server = String(new FormData(event.target).get("server") || "").trim().replace(/\/$/, "");
    await fetch("/api/connection", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ server: state.server }),
    });
    state.serverOpen = false;
    if (state.view === "day") loadWeek(state.focus);
    else loadBoard();
  });
  document.querySelectorAll("[data-date]").forEach((button) => {
    button.onclick = () => {
      state.panel = null;
      state.dicts = false;
      state.teachersPane = "";
      state.noticePane = "";
      state.search = "";
      state.searchHits = null;
      state.view = "day";
      loadWeek(button.dataset.date);
    };
  });
  document.querySelector("[data-today]")?.addEventListener("click", () => {
    state.view = "day";
    state.dicts = false;
    loadWeek(localDate());
  });
  document.querySelectorAll("[data-move]").forEach((button) => {
    button.onclick = () => move(Number(button.dataset.move));
  });
  document.querySelectorAll("[data-view]").forEach((button) => {
    button.onclick = () => showView(button.dataset.view);
  });
  document.querySelector("[data-dicts]")?.addEventListener("click", () => {
    state.dicts = !state.dicts;
    render();
  });
  document.querySelectorAll("[data-panel]").forEach((button) => {
    button.onclick = () => openPanel(button.dataset.panel);
  });
  document.querySelector("#dash-search")?.addEventListener("input", (event) => {
    state.search = event.target.value;
    state.searchHits = null;
    render();
    scheduleSearch();
  });
  document.querySelectorAll("[data-notice]").forEach((button) => {
    button.onclick = () => {
      const pane = button.dataset.notice;
      state.noticePane = state.noticePane === pane ? "" : pane;
      render();
    };
  });
  document.querySelectorAll("[data-teachers]").forEach((button) => {
    button.onclick = () => {
      const pane = button.dataset.teachers;
      state.teachersPane = state.teachersPane === pane ? "" : pane;
      render();
    };
  });
  document.querySelectorAll("[data-new]").forEach((button) => {
    button.onclick = () => openForm({});
  });
  document.querySelectorAll("[data-edit]").forEach((button) => {
    button.onclick = () => {
      const [type, id] = String(button.dataset.edit).split(":");
      const item = state.week.todo.find((row) => (row.type || "event") === (type || "event") && row.id === Number(id));
      if (item) openForm(item);
    };
  });
  document.querySelectorAll("[data-jump]").forEach((button) => {
    button.onclick = () => loadWeek(button.dataset.jump);
  });
  document.querySelectorAll("[data-open]").forEach((button) => {
    button.onclick = (event) => {
      event.stopPropagation();
      if (state.skipOpen) {
        state.skipOpen = false;
        return;
      }
      const [type, id] = button.dataset.open.split(":");
      const list = type === "work" ? state.week.works : state.week.events;
      const item = list.find((entry) => entry.id === Number(id));
      if (item) openForm(item);
    };
    button.onmouseenter = () => highlightTeacher(button.dataset.teacher);
    button.onmouseleave = () => highlightTeacher("");
  });
  document.querySelectorAll("[data-teacher]").forEach((button) => {
    if (button.dataset.open) return;
    button.onmouseenter = () => highlightTeacher(button.dataset.teacher);
    button.onmouseleave = () => highlightTeacher("");
    button.onclick = () => {
      const teacher = state.week.teachers.find((item) => item.id === Number(button.dataset.teacher));
      if (teacher?.eventId) {
        const list = teacher.source === "work" ? state.week.works : state.week.events;
        const item = list.find((entry) => entry.id === teacher.eventId);
        if (item) openForm(item);
      } else if (teacher) openForm({ teacherId: teacher.id });
    };
  });
  bindDayBoard();
  document.querySelectorAll("[data-close]").forEach((button) => {
    button.onclick = () => {
      state.form = null;
      state.panel = null;
      state.dictDraft = null;
      render();
    };
  });
  const form = document.querySelector("#event-form");
  if (form) bindEventForm(form);
  document.querySelector("#teacher-form")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.target));
    const id = state.dictDraft?.kind === "teachers" ? state.dictDraft.id : null;
    const response = await api(id ? `/api/teachers/${id}` : "/api/teachers", {
      method: id ? "PUT" : "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) return;
    state.dictDraft = null;
    const panel = state.panel;
    if (state.view === "day") await loadWeek(state.focus);
    else await loadBoard();
    state.panel = panel;
    render();
  });
  document.querySelector("#people-search")?.addEventListener("input", (event) => {
    state.teacherQuery = event.target.value;
    render();
  });
  document.querySelector("#class-form")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.target));
    const id = state.dictDraft?.kind === "classes" ? state.dictDraft.id : null;
    const response = await api(id ? `/api/classes/${id}` : "/api/classes", {
      method: id ? "PUT" : "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) return;
    state.dictDraft = null;
    state.lookups = await (await api("/api/lookups")).json();
    render();
  });
  document.querySelector("#named-form")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const kind = event.target.dataset.named;
    const data = Object.fromEntries(new FormData(event.target));
    const id = state.dictDraft?.kind === kind ? state.dictDraft.id : null;
    const response = await api(id ? `/api/${kind}/${id}` : `/api/${kind}`, {
      method: id ? "PUT" : "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) return;
    state.dictDraft = null;
    state.lookups = await (await api("/api/lookups")).json();
    render();
  });
  document.querySelector("[data-cancel-edit]")?.addEventListener("click", () => {
    state.dictDraft = null;
    render();
  });
  document.querySelectorAll("[data-edit-dict]").forEach((button) => {
    button.onclick = () => beginDictEdit(button.dataset.editDict);
  });
  document.querySelectorAll("[data-delete-dict]").forEach((button) => {
    const [kind, id] = button.dataset.deleteDict.split(":");
    button.onclick = () => removeDict(kind, id);
  });
}

async function showView(view) {
  state.view = view;
  state.panel = null;
  state.dicts = false;
  if (view === "day") {
    await loadWeek(state.focus);
    return;
  }
  await loadBoard();
}

async function loadBoard() {
  state.error = "";
  try {
    const response = await api(`/api/board?view=${state.view}&date=${state.focus}`);
    if (!response.ok) throw new Error("fail");
    state.board = await response.json();
  } catch {
    state.board = null;
    state.error = "Календарь на этом компьютере не открылся.";
  }
  render();
}

async function move(direction) {
  state.dicts = false;
  if (state.view === "day") {
    await loadWeek(addDays(state.focus, direction));
    return;
  }
  const target = direction < 0 ? state.board?.prev : state.board?.next;
  if (!target) return;
  state.focus = target;
  await loadBoard();
}

async function openList(kind) {
  state.form = null;
  state.dicts = false;
  const from = state.view === "day" ? state.week.weekStart : state.board?.start;
  const to = state.view === "day" ? addDays(state.week.weekStart, 6) : state.board?.end;
  const response = await api(`/api/list?kind=${kind}&from=${from}&to=${to}`);
  state.list = await response.json();
  state.panel = kind;
  render();
}

async function removeDict(kind, id) {
  const questions = {
    teachers: "Удалить этого учителя?",
    classes: "Удалить этот класс?",
    kinds: "Удалить этот вид контрольной?",
    subjects: "Удалить этот предмет?",
  };
  if (!confirm(questions[kind] || "Удалить?")) return;
  const response = await api(`/api/${kind}/${id}`, { method: "DELETE" });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    alert(body.error || "Не получилось удалить");
    return;
  }
  if (state.dictDraft?.id === Number(id)) state.dictDraft = null;
  state.lookups = await (await api("/api/lookups")).json();
  const panel = state.panel;
  if (state.view === "day") await loadWeek(state.focus);
  else await loadBoard();
  state.panel = panel;
  render();
}

function beginDictEdit(token) {
  const [kind, id] = token.split(":");
  if (kind === "teachers") {
    const teacher = (state.week?.teachers || []).find((item) => String(item.id) === id);
    if (!teacher) return;
    state.dictDraft = {
      kind,
      id: teacher.id,
      lastName: teacher.lastName || "",
      firstName: teacher.firstName || "",
      patronymic: teacher.patronymic || "",
    };
  } else if (kind === "classes") {
    const item = (state.lookups?.classes || []).find((row) => String(row.id) === id);
    if (!item) return;
    state.dictDraft = { kind, id: item.id, name: item.name };
  } else {
    const lists = { kinds: state.lookups?.kinds, subjects: state.lookups?.subjects };
    const list = lists[kind];
    const item = (list || []).find((row) => String(row.id) === id);
    if (!item) return;
    state.dictDraft = { kind, id: item.id, name: item.name };
  }
  render();
}

async function openPanel(name) {
  state.form = null;
  state.dicts = false;
  state.dictDraft = null;
  state.panel = name;
  if (name !== "teachers") state.lookups = await (await api("/api/lookups")).json();
  render();
}

async function openSettings() {
  state.serverOpen = !state.serverOpen;
  if (state.serverOpen) {
    try {
      state.version = (await (await fetch("/api/version")).json()).version || state.version;
    } catch {
      /* номер останется с прошлого запроса */
    }
  }
  render();
}

async function saveExcel(customPath) {
  const folder = String(customPath || state.excel?.folder || "").trim();
  if (!folder) {
    state.excel = { ...(state.excel || {}), error: "Укажите папку для сохранения" };
    render();
    return;
  }
  const response = await fetch("/api/export", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ view: state.view, date: state.focus, place: "custom", path: folder }),
  });
  if (!response.ok) {
    state.excel = { folder, name: "", error: "Папка не найдена или недоступна" };
    render();
    return;
  }
  const saved = await response.json();
  state.excel = { folder: saved.folder, name: saved.name, error: "" };
  render();
}

function bindExcel() {
  document.querySelector("[data-close-save]")?.addEventListener("click", (event) => {
    if (event.target !== event.currentTarget) return;
    state.excel = null;
    render();
  });
  document.querySelector("[data-stop]")?.addEventListener("click", (event) => event.stopPropagation());
  document.querySelector("#excel-path")?.addEventListener("input", (event) => {
    state.excel = { ...(state.excel || {}), folder: event.target.value, name: "", error: "" };
    const save = document.querySelector("[data-save-excel]");
    const open = document.querySelector("[data-open-folder]");
    if (save) save.disabled = !event.target.value.trim();
    if (open) open.disabled = !event.target.value.trim();
  });
  document.querySelector("[data-pick-folder]")?.addEventListener("click", async () => {
    const response = await fetch("/api/pick-folder", { method: "POST" });
    const picked = await response.json();
    if (!picked.folder) return;
    state.excel = { folder: picked.folder, name: "", error: "" };
    render();
  });
  document.querySelector("[data-open-folder]")?.addEventListener("click", () => {
    const folder = document.querySelector("#excel-path")?.value || state.excel?.folder;
    fetch("/api/open-folder", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ folder }),
    });
  });
  document.querySelector("[data-save-excel]")?.addEventListener("click", () => {
    const folder = document.querySelector("#excel-path")?.value || state.excel?.folder;
    saveExcel(folder);
  });
}

function bindUpdate() {
  document.querySelector("[data-update-later]")?.addEventListener("click", () => {
    if (state.updateTimer) clearInterval(state.updateTimer);
    state.update = { ...(state.update || {}), dismissed: true };
    render();
  });
  document.querySelector("[data-update-start]")?.addEventListener("click", async () => {
    const progress = await (await fetch("/api/update/download", { method: "POST" })).json();
    state.update = { ...(state.update || {}), ...progress, dismissed: false };
    render();
    if (state.updateTimer) clearInterval(state.updateTimer);
    state.updateTimer = setInterval(async () => {
      const next = await (await fetch("/api/update/progress")).json();
      state.update = { ...(state.update || {}), ...next, dismissed: false };
      render();
      if (next.status === "ready" || next.status === "applying") {
        clearInterval(state.updateTimer);
        state.updateTimer = null;
        fetch("/api/update/apply", { method: "POST" }).catch(() => {});
      } else if (next.status === "error" || next.status === "idle") {
        clearInterval(state.updateTimer);
        state.updateTimer = null;
      }
    }, 400);
  });
}

async function checkForUpdate() {
  try {
    const info = await (await fetch("/api/update")).json();
    if (!info.available) return;
    state.update = {
      available: true,
      version: info.version,
      current: info.current,
      notes: info.notes || "",
      status: "idle",
      percent: 0,
      message: "",
      dismissed: false,
    };
    render();
  } catch {
    /* сеть недоступна — пропускаем */
  }
}

async function pickBackupFile(kind) {
  const response = await fetch("/api/backup/pick", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ kind }),
  });
  if (!response.ok) return "";
  const data = await response.json();
  return data.file || "";
}

async function exportBackup() {
  const file = await pickBackupFile("save");
  if (!file) return;
  const response = await fetch("/api/backup/export", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ path: file }),
  });
  const data = await response.json().catch(() => ({}));
  state.backupNote = response.ok ? `Сохранено: ${data.name || "файл"}` : (data.error || "Не удалось выгрузить");
  render();
}

async function importBackup() {
  const file = await pickBackupFile("open");
  if (!file) return;
  if (!confirm("Заменить календарь данными из этого файла?")) return;
  const response = await fetch("/api/backup/import", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ path: file }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    state.backupNote = data.error || "Не удалось загрузить";
    render();
    return;
  }
  state.backupNote = "Календарь загружен из файла";
  state.serverOpen = false;
  if (state.view === "day") await loadWeek(state.focus);
  else await loadBoard();
}

async function restoreBackup(name) {
  if (!confirm("Вернуть эту копию?")) return;
  const response = await fetch("/api/backups/restore", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ name }),
  });
  if (!response.ok) return;
  state.serverOpen = false;
  if (state.view === "day") await loadWeek(state.focus);
  else await loadBoard();
}

async function setWritable(writable) {
  state.writable = writable;
  if (!writable) state.form = null;
  await fetch("/api/connection", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ writable }),
  });
  render();
}

async function openForm(source) {
  if (!state.writable) return;
  state.panel = null;
  const teacherIds = source.teacherIds?.length
    ? source.teacherIds
    : source.teacherId
      ? [source.teacherId]
      : [];
  state.form = {
    id: source.id || null,
    date: source.date || state.focus,
    endDate: source.endDate || "",
    start: source.start || "",
    end: source.end || "",
    allDay: Boolean(source.allDay),
    title: source.title || "",
    audience: source.audience || "",
    wholeSchool: Boolean(source.wholeSchool) || source.audience === "вся школа",
    note: source.note || "",
    teacherId: teacherIds[0] || "",
    teacherIds,
    kind: source.type === "work" ? "work" : "event",
    kindName: source.detail || "",
    classIds: source.classIds || [],
    query: "",
  };
  if (!state.lookups) state.lookups = await (await api("/api/lookups")).json();
  await refreshBusy();
  render();
  document.querySelector("#field-title")?.focus();
}

async function refreshBusy() {
  const form = state.form;
  if (!form?.date) return;
  const start = form.allDay ? "" : form.start || "";
  const end = form.allDay ? "" : form.end || "";
  const response = await api(`/api/busy?date=${form.date}&start=${start}&end=${end}`);
  state.busy = (await response.json()).teachers;
}

function bindEventForm(form) {
  const sync = async () => {
    const data = Object.fromEntries(new FormData(form));
    state.form = {
      ...state.form,
      ...data,
      allDay: Boolean(form.querySelector("[name=allDay]")?.checked),
      classIds: state.form.classIds || [],
      teacherIds: state.form.teacherIds || [],
      wholeSchool: Boolean(state.form.wholeSchool),
    };
    if (state.form.allDay) {
      state.form.start = "";
      state.form.end = "";
    }
    await refreshBusy();
    render();
  };
  form.querySelector("#field-date").onchange = sync;
  form.querySelector("#field-start").onchange = sync;
  form.querySelector("[name=allDay]")?.addEventListener("change", sync);
  form.querySelectorAll("[data-kind]").forEach((button) => {
    button.onclick = () => {
      state.form.kind = button.dataset.kind;
      render();
    };
  });
  form.querySelectorAll("[data-fold]").forEach((button) => {
    button.onclick = () => {
      const key = button.dataset.fold;
      state.form[key] = !state.form[key];
      render();
    };
  });
  form.querySelectorAll("[data-grade]").forEach((button) => {
    button.onclick = () => {
      const grade = Number(button.dataset.grade);
      const ofGrade = classList().filter((item) => item.grade === grade).map((item) => String(item.id));
      const set = new Set((state.form.classIds || []).map(String));
      const allOn = ofGrade.length && ofGrade.every((id) => set.has(id));
      if (allOn) ofGrade.forEach((id) => set.delete(id));
      else ofGrade.forEach((id) => set.add(id));
      state.form.classIds = [...set];
      state.form.wholeSchool = false;
      state.form.audience = "";
      render();
    };
  });
  form.querySelector("[data-whole-school]")?.addEventListener("click", () => {
    state.form.wholeSchool = !state.form.wholeSchool;
    if (state.form.wholeSchool) {
      state.form.classIds = [];
      state.form.audience = "вся школа";
    } else {
      state.form.audience = "";
    }
    render();
  });
  form.querySelectorAll("[data-class-id]").forEach((button) => {
    button.onclick = () => {
      const id = button.dataset.classId;
      const set = new Set((state.form.classIds || []).map(String));
      if (set.has(id)) set.delete(id);
      else set.add(id);
      state.form.classIds = [...set];
      state.form.wholeSchool = false;
      state.form.audience = "";
      render();
    };
  });
  form.querySelectorAll("[data-teacher-id]").forEach((button) => {
    button.onclick = () => {
      const id = button.dataset.teacherId;
      const set = new Set((state.form.teacherIds || []).map(String));
      if (set.has(id)) set.delete(id);
      else set.add(id);
      state.form.teacherIds = [...set];
      state.form.teacherId = state.form.teacherIds[0] || "";
      render();
    };
  });
  form.querySelector("[data-delete]")?.addEventListener("click", async () => {
    const path = state.form.kind === "work" ? "works" : "events";
    await api(`/api/${path}/${state.form.id}`, { method: "DELETE" });
    state.form = null;
    loadWeek(state.focus);
  });
  form.onsubmit = async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    const payload = {
      ...data,
      allDay: Boolean(form.querySelector("[name=allDay]")?.checked),
      classIds: state.form.classIds || [],
      teacherIds: state.form.teacherIds || [],
      teacherId: (state.form.teacherIds || [])[0] || null,
      wholeSchool: Boolean(state.form.wholeSchool),
      audience: state.form.wholeSchool ? "вся школа" : "",
      start: form.querySelector("[name=allDay]")?.checked ? "" : data.start,
      end: form.querySelector("[name=allDay]")?.checked ? "" : data.end,
    };
    const isWork = state.form.kind === "work";
    const url = isWork
      ? (state.form.id ? `/api/works/${state.form.id}` : "/api/works")
      : (state.form.id ? `/api/events/${state.form.id}` : "/api/events");
    const method = state.form.id ? "PUT" : "POST";
    const response = await api(url, { method, headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
    if (!response.ok) return;
    const focus = data.date;
    state.form = null;
    loadWeek(focus);
  };
}

document.documentElement.removeAttribute("data-theme");
localStorage.removeItem("azbuki-theme");
localStorage.removeItem("azbuki-server");

function bindLicense() {
  document.querySelector("#license-form")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const key = String(new FormData(event.target).get("key") || "").trim();
    const response = await fetch("/api/license", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ key }),
    });
    state.license = await response.json();
    if (!licenseBlocks()) await loadWeek(state.focus || localDate());
    else render();
  });
  document.querySelector("#license-retry")?.addEventListener("click", async () => {
    state.license = null;
    render();
    await refreshLicense();
  });
}

async function refreshLicense() {
  const wasBlocked = licenseBlocks();
  const previous = state.license?.state;
  try {
    state.license = await (await fetch("/api/license")).json();
  } catch {
    state.license = { state: "offline", error: "Не удалось проверить лицензию на этом компьютере." };
  }
  if (licenseBlocks()) {
    if (state.license.state !== previous) render();
    return;
  }
  if (!state.week || wasBlocked) await loadWeek(state.focus || localDate());
}

async function boot() {
  try {
    const saved = await (await fetch("/api/connection")).json();
    state.server = String(saved.server || "").replace(/\/$/, "");
    state.writable = saved.writable !== false;
  } catch {
    state.server = "";
  }
  try {
    state.version = (await (await fetch("/api/version")).json()).version || "";
  } catch {
    state.version = "";
  }
  await refreshLicense();
  checkForUpdate();
}

boot();
setInterval(ping, 8000);
setInterval(refreshLicense, 120000);
