import { execFile, spawn, spawnSync } from "node:child_process";
import crypto from "node:crypto";
import fs from "node:fs";
import http from "node:http";
import https from "node:https";
import os from "node:os";
import path from "node:path";
import zlib from "node:zlib";
import { DatabaseSync } from "node:sqlite";
import { seed } from "./lib/seed.js";

const root = import.meta.dirname;
const port = process.env.PORT == null ? 4173 : Number(process.env.PORT);
const host = process.env.HOST || "127.0.0.1";
const isDesktop = host === "127.0.0.1";
const dataDir = path.join(root, "data");
fs.mkdirSync(dataDir, { recursive: true });
const connectionFile = path.join(dataDir, "connection.json");
const defaultServer = "http://168.113.156.99:4173";
if (!fs.existsSync(connectionFile)) {
  fs.writeFileSync(connectionFile, JSON.stringify({ server: defaultServer }, null, 2));
}

const outboxFile = path.join(dataDir, "outbox.json");
const snapshotTables = [
  "meta", "teachers", "classes", "subjects", "kinds", "periods",
  "events", "works", "work_classes", "event_teachers", "work_teachers", "event_classes", "event_kinds",
];
function appVersion() {
  try {
    return JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8")).version || "0.1.0";
  } catch {
    return "0.1.0";
  }
}
const RELEASES_REPO = "avatorsk-ux/Releases";
const updateJob = {
  status: "idle",
  percent: 0,
  message: "",
  version: "",
  notes: "",
  url: "",
  size: 0,
  zipPath: "",
};
function readOutbox() {
  try {
    const saved = JSON.parse(fs.readFileSync(outboxFile, "utf8"));
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function writeOutbox(items) {
  fs.writeFileSync(outboxFile, JSON.stringify(items, null, 2));
}

function noteChange(entry) {
  if (!isDesktop) return;
  writeOutbox([...readOutbox(), entry]);
}

function noteWithoutTeachers(note) {
  return String(note || "").replace(/(?:\n|^)\[\[resp:[\d,]+\]\]$/, "");
}

function teacherIdsFromNote(note) {
  const match = String(note || "").match(/(?:\n|^)\[\[resp:([\d,]+)\]\]$/);
  if (!match) return [];
  return [...new Set(match[1].split(",").map(Number).filter(Boolean))];
}

function noteForSync(note, teacherIds) {
  const clean = noteWithoutTeachers(note);
  const ids = [...new Set((teacherIds || []).map(Number).filter(Boolean))];
  if (ids.length < 2) return clean;
  return `${clean}${clean ? "\n" : ""}[[resp:${ids.join(",")}]]`;
}

function restoreTeachersFromNotes() {
  for (const row of db.prepare("SELECT id, note FROM events").all()) {
    const ids = teacherIdsFromNote(row.note);
    if (ids.length < 2) continue;
    setEventTeachers(row.id, ids);
    db.prepare("UPDATE events SET note = ? WHERE id = ?").run(noteWithoutTeachers(row.note), row.id);
  }
  for (const row of db.prepare("SELECT id, note FROM works").all()) {
    const ids = teacherIdsFromNote(row.note);
    if (ids.length < 2) continue;
    setWorkTeachers(row.id, ids);
    db.prepare("UPDATE works SET note = ? WHERE id = ?").run(noteWithoutTeachers(row.note), row.id);
  }
}
function snapshot() {
  const data = {};
  for (const name of snapshotTables) data[name] = db.prepare(`SELECT * FROM ${name}`).all();
  return data;
}

function dataRevision() {
  const hash = crypto.createHash("sha1");
  for (const name of snapshotTables) {
    const columns = db.prepare(`PRAGMA table_info(${name})`).all().map((column) => column.name);
    hash.update(name);
    for (const row of db.prepare(`SELECT * FROM ${name}`).all()) {
      hash.update(JSON.stringify(columns.map((column) => row[column])));
    }
  }
  return hash.digest("hex").slice(0, 16);
}

function syncStatus(online, pending) {
  let revision = "";
  try {
    revision = dataRevision();
  } catch {
    revision = "";
  }
  return { online, pending, revision };
}

function backupDir() {
  const dir = path.join(dataDir, "backups");
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function todayStamp() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}

function ensureDailyBackup() {
  if (!fs.existsSync(dbFile)) return;
  const dir = backupDir();
  const target = path.join(dir, `school-${todayStamp()}.db.gz`);
  if (!fs.existsSync(target)) {
    const plain = path.join(dir, `school-${todayStamp()}.db`);
    const sqlPath = plain.replaceAll("\\", "/").replaceAll("'", "''");
    try {
      db.exec(`VACUUM INTO '${sqlPath}'`);
    } catch {
      fs.copyFileSync(dbFile, plain);
    }
    fs.writeFileSync(target, zlib.gzipSync(fs.readFileSync(plain)));
    fs.unlinkSync(plain);
  }
  for (const name of fs.readdirSync(dir)) {
    if (name.endsWith(".db")) fs.unlinkSync(path.join(dir, name));
  }
  const files = fs.readdirSync(dir).filter((name) => name.endsWith(".db.gz")).sort();
  while (files.length > 7) fs.unlinkSync(path.join(dir, files.shift()));
}

function listBackups() {
  const dir = path.join(dataDir, "backups");
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter((name) => /^school-\d{4}-\d{2}-\d{2}\.db\.gz$/.test(name)).sort().reverse().map((name) => {
    const [year, month, day] = name.slice(7, 17).split("-");
    return { name, label: `${day}.${month}.${year}` };
  });
}

function restoreBackup(name) {
  if (!/^school-\d{4}-\d{2}-\d{2}\.db\.gz$/.test(name)) return false;
  const source = path.join(dataDir, "backups", name);
  if (!fs.existsSync(source)) return false;
  const plain = zlib.gunzipSync(fs.readFileSync(source));
  db.close();
  fs.writeFileSync(dbFile, plain);
  db = new DatabaseSync(dbFile);
  db.exec("PRAGMA foreign_keys = ON");
  return true;
}

function knownDirs() {
  const home = os.homedir();
  const pick = (list) => list.find((dir) => fs.existsSync(dir)) || list[0];
  return {
    desktop: pick([path.join(home, "Desktop"), path.join(home, "OneDrive", "Desktop"), path.join(home, "Рабочий стол")]),
    documents: pick([path.join(home, "Documents"), path.join(home, "OneDrive", "Documents"), path.join(home, "Документы")]),
    downloads: pick([path.join(home, "Downloads"), path.join(home, "Загрузки")]),
  };
}

function saveExcelFile(view, date, place, customPath) {
  const dirs = knownDirs();
  const folder = place === "custom" ? path.resolve(String(customPath || "")) : dirs[place];
  if (!folder || !fs.existsSync(folder) || !fs.statSync(folder).isDirectory()) return null;
  const board = boardPayload(view, date);
  const safe = `Календарь ${board.label}`.replace(/[<>:"/\\|?*]/g, "").trim();
  const file = path.join(folder, `${safe}.xls`);
  fs.writeFileSync(file, excelWorkbook(board), "utf8");
  return { name: path.basename(file), folder };
}

function openFolder(folder) {
  const resolved = path.resolve(String(folder || ""));
  if (!fs.existsSync(resolved) || !fs.statSync(resolved).isDirectory()) return false;
  spawn("explorer.exe", [resolved], { detached: true, stdio: "ignore" }).unref();
  return true;
}

function pickFolder() {
  const out = path.join(os.tmpdir(), `azbuki-folder-${process.pid}-${Date.now()}.txt`);
  const escaped = out.replace(/'/g, "''");
  const script = [
    "Add-Type -AssemblyName System.Windows.Forms",
    "$dialog = New-Object System.Windows.Forms.FolderBrowserDialog",
    "$dialog.Description = 'Папка для Excel'",
    `if ($dialog.ShowDialog() -eq 'OK') { [IO.File]::WriteAllText('${escaped}', $dialog.SelectedPath, [Text.UTF8Encoding]::new($false)) }`,
  ].join("; ");
  return new Promise((resolve) => {
    execFile("powershell.exe", ["-STA", "-NoProfile", "-Command", script], { windowsHide: true }, () => {
      try {
        const folder = fs.readFileSync(out, "utf8").trim();
        fs.unlinkSync(out);
        resolve(folder);
      } catch {
        resolve("");
      }
    });
  });
}

function pickFile(kind) {
  const out = path.join(os.tmpdir(), `azbuki-file-${process.pid}-${Date.now()}.txt`);
  const escaped = out.replace(/'/g, "''");
  const save = kind === "save";
  const script = [
    "Add-Type -AssemblyName System.Windows.Forms",
    `$dialog = New-Object System.Windows.Forms.${save ? "SaveFileDialog" : "OpenFileDialog"}`,
    "$dialog.Filter = 'JSON (*.json)|*.json'",
    `$dialog.Title = '${save ? "Куда сохранить копию" : "Файл копии JSON"}'`,
    save ? "$dialog.FileName = 'kalendar.json'" : "",
    `if ($dialog.ShowDialog() -eq 'OK') { [IO.File]::WriteAllText('${escaped}', $dialog.FileName, [Text.UTF8Encoding]::new($false)) }`,
  ].filter(Boolean).join("; ");
  return new Promise((resolve) => {
    execFile("powershell.exe", ["-STA", "-NoProfile", "-Command", script], { windowsHide: true }, () => {
      try {
        const file = fs.readFileSync(out, "utf8").trim();
        fs.unlinkSync(out);
        resolve(file);
      } catch {
        resolve("");
      }
    });
  });
}

function parseVersion(value) {
  const match = String(value || "").match(/(\d+)\.(\d+)\.(\d+)/);
  if (!match) return null;
  return [Number(match[1]), Number(match[2]), Number(match[3])];
}

function compareVersions(left, right) {
  const a = parseVersion(left);
  const b = parseVersion(right);
  if (!a || !b) return 0;
  for (let index = 0; index < 3; index += 1) {
    const diff = a[index] - b[index];
    if (diff) return diff;
  }
  return 0;
}

function isPlanRelease(tag, assetName = "") {
  const name = String(tag || "");
  const file = String(assetName || "");
  if (/^(plan|kalendar|azbuki)[-_]/i.test(name)) return true;
  if (/^(plan|kalendar|azbuki|календар)/i.test(file)) return true;
  return /^v?\d+\.\d+\.\d+$/i.test(name);
}

function githubGet(url) {
  return new Promise((resolve, reject) => {
    const request = https.get(url, {
      headers: {
        "user-agent": "azbuki-plan",
        accept: "application/vnd.github+json",
      },
      timeout: 10000,
    }, (response) => {
      if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
        response.resume();
        return resolve(githubGet(response.headers.location));
      }
      const chunks = [];
      response.on("data", (chunk) => chunks.push(chunk));
      response.on("end", () => {
        const body = Buffer.concat(chunks).toString("utf8");
        if (response.statusCode && response.statusCode >= 400) {
          reject(new Error(`GitHub ${response.statusCode}`));
          return;
        }
        try {
          resolve(JSON.parse(body));
        } catch (error) {
          reject(error);
        }
      });
    });
    request.on("error", reject);
    request.on("timeout", () => {
      request.destroy();
      reject(new Error("timeout"));
    });
  });
}

function downloadFile(url, dest, onProgress) {
  return new Promise((resolve, reject) => {
    const follow = (target) => {
      const request = https.get(target, {
        headers: { "user-agent": "azbuki-plan", accept: "application/octet-stream" },
        timeout: 60000,
      }, (response) => {
        if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
          response.resume();
          return follow(response.headers.location);
        }
        if (response.statusCode && response.statusCode >= 400) {
          response.resume();
          reject(new Error(`Скачивание ${response.statusCode}`));
          return;
        }
        const total = Number(response.headers["content-length"] || 0);
        let received = 0;
        const file = fs.createWriteStream(dest);
        response.on("data", (chunk) => {
          received += chunk.length;
          if (total) onProgress(Math.min(99, Math.round((received / total) * 100)));
          else onProgress(Math.min(90, Math.round(received / 1024 / 100)));
        });
        response.pipe(file);
        file.on("finish", () => {
          file.close(() => {
            onProgress(100);
            resolve();
          });
        });
        file.on("error", reject);
      });
      request.on("error", reject);
      request.on("timeout", () => {
        request.destroy();
        reject(new Error("timeout"));
      });
    };
    follow(url);
  });
}

function releaseInfo(version, notes, url, size, name) {
  return {
    available: true,
    current: appVersion(),
    version,
    notes: String(notes || "").slice(0, 500),
    url,
    size: Number(size || 0),
    name,
  };
}

function newerFromList(list) {
  let best = null;
  for (const release of list) {
    if (release.draft || release.prerelease) continue;
    const tag = String(release.tag_name || "");
    const assets = Array.isArray(release.assets) ? release.assets : [];
    const asset = assets.find((item) => /\.zip$/i.test(item.name) && isPlanRelease(tag, item.name))
      || (isPlanRelease(tag) ? assets.find((item) => /\.zip$/i.test(item.name)) : null);
    if (!asset?.browser_download_url) continue;
    const version = (tag.match(/(\d+\.\d+\.\d+)/) || [])[1];
    if (!version || compareVersions(version, appVersion()) <= 0) continue;
    if (best && compareVersions(version, best.version) <= 0) continue;
    best = releaseInfo(version, release.body || release.name, asset.browser_download_url, asset.size, asset.name);
  }
  return best;
}

function zipExists(url) {
  return new Promise((resolve) => {
    const request = https.request(url, { method: "HEAD", headers: { "user-agent": "azbuki-plan" }, timeout: 10000 }, (response) => {
      response.resume();
      if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
        resolve(zipExists(response.headers.location));
        return;
      }
      resolve(response.statusCode === 200);
    });
    request.on("error", () => resolve(false));
    request.on("timeout", () => {
      request.destroy();
      resolve(false);
    });
    request.end();
  });
}

async function checkUpdateByZip() {
  const current = parseVersion(appVersion()) || [0, 2, 0];
  let found = null;
  let misses = 0;
  for (let patch = current[2] + 1; patch <= current[2] + 40; patch += 1) {
    const version = `${current[0]}.${current[1]}.${patch}`;
    const name = `plan-${version}.zip`;
    const url = `https://github.com/${RELEASES_REPO}/releases/download/plan-${version}/${name}`;
    if (await zipExists(url)) {
      found = releaseInfo(version, "", url, 0, name);
      misses = 0;
    } else {
      misses += 1;
      if (found && misses >= 3) break;
      if (!found && misses >= 30) break;
    }
  }
  return found;
}

async function checkUpdate() {
  try {
    const releases = await githubGet(`https://api.github.com/repos/${RELEASES_REPO}/releases?per_page=30`);
    const list = Array.isArray(releases) ? releases : [];
    const found = newerFromList(list);
    if (found) return found;
    return { available: false, current: appVersion() };
  } catch {
    try {
      const found = await checkUpdateByZip();
      if (found) return found;
    } catch {
      /* полка недоступна */
    }
    return { available: false, current: appVersion() };
  }
}

function updateProgress() {
  return {
    status: updateJob.status,
    percent: updateJob.percent,
    message: updateJob.message,
    version: updateJob.version,
    notes: updateJob.notes,
    current: appVersion(),
  };
}

async function startUpdateDownload() {
  if (updateJob.status === "downloading" || updateJob.status === "applying") return updateProgress();
  if (updateJob.status === "ready") {
    applyUpdate();
    return updateProgress();
  }
  const info = await checkUpdate();
  if (!info.available) {
    updateJob.status = "idle";
    updateJob.message = "Обновлений нет";
    return updateProgress();
  }
  updateJob.status = "downloading";
  updateJob.percent = 0;
  updateJob.message = "Скачиваю обновление…";
  updateJob.version = info.version;
  updateJob.notes = info.notes;
  updateJob.url = info.url;
  updateJob.size = info.size;
  const dir = path.join(dataDir, "updates");
  fs.mkdirSync(dir, { recursive: true });
  updateJob.zipPath = path.join(dir, `update-${info.version}.zip`);
  downloadFile(info.url, updateJob.zipPath, (percent) => {
    updateJob.percent = percent;
    updateJob.message = `Скачиваю ${percent}%`;
  }).then(() => {
    updateJob.status = "ready";
    updateJob.percent = 100;
    updateJob.message = "Скачано. Перезапускаю…";
    applyUpdate();
  }).catch((error) => {
    updateJob.status = "error";
    updateJob.message = error.message || "Не удалось скачать";
  });
  return updateProgress();
}

function findAppExe() {
  const names = fs.readdirSync(root).filter((name) => /\.exe$/i.test(name) && !/^node\.exe$/i.test(name));
  const preferred = names.find((name) => /план|календар/i.test(name)) || names[0];
  return preferred ? path.join(root, preferred) : "";
}

function applyUpdate() {
  if (updateJob.status === "applying") return updateProgress();
  if (!updateJob.zipPath || !fs.existsSync(updateJob.zipPath)) {
    return { ok: false, error: "Сначала скачайте обновление" };
  }
  updateJob.status = "applying";
  updateJob.percent = 100;
  updateJob.message = "Перезапускаю программу…";
  const zip = updateJob.zipPath;
  const staging = path.join(dataDir, "updates", "staging");
  const script = path.join(dataDir, "updates", "apply.ps1");
  const log = path.join(dataDir, "update.log");
  const exe = findAppExe();
  const lines = [
    `$ErrorActionPreference = 'Continue'`,
    `$root = ${JSON.stringify(root)}`,
    `$zip = ${JSON.stringify(zip)}`,
    `$staging = ${JSON.stringify(staging)}`,
    `$exe = ${JSON.stringify(exe)}`,
    `$nodePid = ${process.pid}`,
    `$log = ${JSON.stringify(log)}`,
    `function note($text) { Add-Content -LiteralPath $log -Value $text }`,
    `note "start $(Get-Date -Format o)"`,
    `$rootNorm = [IO.Path]::GetFullPath($root).TrimEnd('\\')`,
    `function Close-Old {`,
    `  Get-CimInstance Win32_Process | ForEach-Object {`,
    `    if ($_.ProcessId -eq $PID) { return }`,
    `    $path = $_.ExecutablePath`,
    `    $cmd = [string]$_.CommandLine`,
    `    $hit = $false`,
    `    if ($path) {`,
    `      $full = [IO.Path]::GetFullPath($path)`,
    `      if ($full.StartsWith($rootNorm + '\\', [StringComparison]::OrdinalIgnoreCase)) { $hit = $true }`,
    `    }`,
    `    if ($cmd.IndexOf($rootNorm, [StringComparison]::OrdinalIgnoreCase) -ge 0) { $hit = $true }`,
    `    if ($_.ProcessId -eq $nodePid) { $hit = $true }`,
    `    if ($hit) { note "stop $(\${_.Name}) $(\${_.ProcessId})"; Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`,
    `  }`,
    `  Get-Process | Where-Object { $_.MainWindowTitle -eq 'План мероприятий' } | ForEach-Object { note "window $($_.Id)"; Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue }`,
    `}`,
    `function Stop-Port {`,
    `  try {`,
    `    Get-NetTCPConnection -LocalPort 4173 -State Listen -ErrorAction SilentlyContinue |`,
    `      Select-Object -ExpandProperty OwningProcess -Unique |`,
    `      ForEach-Object { if ($_ -and $_ -ne $PID) { note "stop port $_"; Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue } }`,
    `  } catch { note "port query failed" }`,
    `}`,
    `function Port-Busy {`,
    `  try {`,
    `    $client = New-Object System.Net.Sockets.TcpClient`,
    `    $client.Connect('127.0.0.1', 4173)`,
    `    $client.Close()`,
    `    return $true`,
    `  } catch { return $false }`,
    `}`,
    `function Wait-PortFree {`,
    `  for ($i = 0; $i -lt 30; $i++) {`,
    `    if (-not (Port-Busy)) { return }`,
    `    Stop-Port`,
    `    Close-Old`,
    `    Start-Sleep -Milliseconds 400`,
    `  }`,
    `  note "port still busy"`,
    `}`,
    `function Open-App {`,
    `  if ($exe -and (Test-Path -LiteralPath $exe)) {`,
    `    Start-Process -FilePath $exe -WorkingDirectory $root`,
    `    note "started $exe"`,
    `  } else { note "exe not found" }`,
    `}`,
    `Close-Old`,
    `Stop-Port`,
    `Wait-PortFree`,
    `if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue }`,
    `New-Item -ItemType Directory -Path $staging -Force | Out-Null`,
    `Expand-Archive -LiteralPath $zip -DestinationPath $staging -Force`,
    `$source = $staging`,
    `if (-not (Test-Path -LiteralPath (Join-Path $staging 'server.js'))) {`,
    `  $inner = Get-ChildItem -LiteralPath $staging -Directory | Select-Object -First 1`,
    `  if ($inner) { $source = $inner.FullName }`,
    `}`,
    `& robocopy $source $root /E /XD data updates /NFL /NDL /NJH /NJS /R:8 /W:1`,
    `note "robocopy $LASTEXITCODE"`,
    `Wait-PortFree`,
    `Open-App`,
    `$wanted = ''`,
    `try { $wanted = (Get-Content -LiteralPath (Join-Path $root 'package.json') -Raw | ConvertFrom-Json).version } catch { note "no version" }`,
    `$seen = ''`,
    `for ($i = 0; $i -lt 25 -and $wanted; $i++) {`,
    `  Start-Sleep -Milliseconds 400`,
    `  try {`,
    `    $resp = Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:4173/api/version' -TimeoutSec 2`,
    `    if ($resp.Content -match ('"version"\\s*:\\s*"' + [regex]::Escape($wanted) + '"')) { $seen = $wanted; break }`,
    `    note "still $($resp.Content)"`,
    `  } catch { }`,
    `}`,
    `if ($wanted -and $seen -ne $wanted) {`,
    `  note "restart, wanted $wanted seen $seen"`,
    `  Stop-Port`,
    `  Wait-PortFree`,
    `  Open-App`,
    `} else { note "version $seen" }`,
  ];
  fs.mkdirSync(path.dirname(script), { recursive: true });
  fs.writeFileSync(script, `\uFEFF${lines.join("\r\n")}`, "utf8");
  const task = "AzbukiKalendarUpdate";
  const tr = `powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "${script}"`;
  const created = spawnSync("schtasks.exe", ["/Create", "/F", "/TN", task, "/SC", "ONCE", "/ST", "00:00", "/IT", "/TR", tr], { windowsHide: true, encoding: "utf8" });
  const ran = spawnSync("schtasks.exe", ["/Run", "/TN", task], { windowsHide: true, encoding: "utf8" });
  fs.appendFileSync(log, `task ${created.status} ${created.stdout || ""} ${created.stderr || ""}\nrun ${ran.status} ${ran.stdout || ""} ${ran.stderr || ""}\n`);
  if (ran.status !== 0) {
    updateJob.status = "error";
    updateJob.message = "Не удалось запустить обновление. Закройте программу и откройте снова.";
    return updateProgress();
  }
  setTimeout(() => process.exit(0), 1500);
  return updateProgress();
}

function applySnapshot(data) {
  const keep = (table, columns) => {
    const names = db.prepare(`PRAGMA table_info(${table})`).all().map((column) => column.name);
    const extra = columns.filter((column) => names.includes(column));
    if (!extra.length) return new Map();
    return new Map(db.prepare(`SELECT id, ${extra.join(", ")} FROM ${table}`).all().map((row) => [row.id, row]));
  };
  const eventKeep = keep("events", ["all_day", "kind_id"]);
  const workKeep = keep("works", ["all_day"]);
  db.exec("PRAGMA foreign_keys = OFF");
  db.exec("BEGIN");
  try {
    const names = Object.keys(data).filter((name) => snapshotTables.includes(name));
    for (const name of [...names].reverse()) db.prepare(`DELETE FROM ${name}`).run();
    for (const name of names) {
      const rows = Array.isArray(data[name]) ? data[name] : [];
      if (!rows.length) continue;
      const columns = Object.keys(rows[0]);
      const insert = db.prepare(
        `INSERT INTO ${name} (${columns.join(", ")}) VALUES (${columns.map(() => "?").join(", ")})`,
      );
      for (const row of rows) insert.run(...columns.map((column) => row[column]));
    }
    const restore = (table, saved, columns) => {
      const present = db.prepare(`PRAGMA table_info(${table})`).all().map((column) => column.name);
      const extra = columns.filter((column) => present.includes(column));
      if (!extra.length) return;
      const update = db.prepare(`UPDATE ${table} SET ${extra.map((column) => `${column} = ?`).join(", ")} WHERE id = ?`);
      for (const [id, row] of saved) {
        if (!db.prepare(`SELECT id FROM ${table} WHERE id = ?`).get(id)) continue;
        update.run(...extra.map((column) => row[column]), id);
      }
    };
    restore("events", eventKeep, ["all_day", "kind_id"]);
    restore("works", workKeep, ["all_day"]);
    restoreTeachersFromNotes();
    db.exec(`
      INSERT OR IGNORE INTO event_teachers (event_id, teacher_id)
      SELECT id, teacher_id FROM events WHERE teacher_id IS NOT NULL;
      INSERT OR IGNORE INTO work_teachers (work_id, teacher_id)
      SELECT id, teacher_id FROM works WHERE teacher_id IS NOT NULL;
      DELETE FROM event_teachers WHERE event_id NOT IN (SELECT id FROM events);
      DELETE FROM work_teachers WHERE work_id NOT IN (SELECT id FROM works);
      DELETE FROM event_classes WHERE event_id NOT IN (SELECT id FROM events);
    `);
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  } finally {
    db.exec("PRAGMA foreign_keys = ON");
  }
}

function foldOutbox(queue) {
  const created = new Map();
  const folded = [];
  for (const item of queue) {
    const key = `${item.kind}:${item.localId}`;
    if (item.op === "create") {
      created.set(key, item);
      folded.push(item);
    } else if (item.op === "update" && created.has(key)) {
      created.get(key).body = item.body;
    } else if (item.op === "delete" && created.has(key)) {
      created.delete(key);
      const index = folded.findIndex((entry) => `${entry.kind}:${entry.localId}` === key && entry.op === "create");
      if (index >= 0) folded.splice(index, 1);
    } else {
      folded.push(item);
    }
  }
  return folded;
}

async function pushChange(remote, item, ids) {
  const json = { "content-type": "application/json" };
  const mapped = (kind, id) => ids[kind]?.[id] || id;
  if (item.kind === "teacher") {
    if (item.op === "delete") {
      const id = mapped("teacher", item.localId);
      const response = await fetch(`${remote}/api/teachers/${id}`, { method: "DELETE" });
      return response.ok || response.status === 404;
    }
    if (item.op === "update") {
      const id = mapped("teacher", item.localId);
      const response = await fetch(`${remote}/api/teachers/${id}`, { method: "PUT", headers: json, body: JSON.stringify(item.body) });
      return response.ok || response.status === 404;
    }
    const response = await fetch(`${remote}/api/teachers`, { method: "POST", headers: json, body: JSON.stringify(item.body) });
    if (!response.ok) return false;
    ids.teacher[item.localId] = (await response.json()).id;
    return true;
  }
  if (item.kind === "class") {
    if (item.op === "delete") {
      const id = mapped("class", item.localId);
      const response = await fetch(`${remote}/api/classes/${id}`, { method: "DELETE" });
      return response.ok || response.status === 404;
    }
    if (item.op === "update") {
      const id = mapped("class", item.localId);
      const response = await fetch(`${remote}/api/classes/${id}`, { method: "PUT", headers: json, body: JSON.stringify(item.body) });
      return response.ok || response.status === 404;
    }
    const response = await fetch(`${remote}/api/classes`, { method: "POST", headers: json, body: JSON.stringify(item.body) });
    if (!response.ok) return false;
    ids.class[item.localId] = (await response.json()).id;
    return true;
  }
  if (item.kind === "eventKind" || item.kind === "workKind" || item.kind === "subject") {
    const path = item.kind === "eventKind" ? "event-kinds" : item.kind === "subject" ? "subjects" : "kinds";
    if (item.op === "delete") {
      const response = await fetch(`${remote}/api/${path}/${item.localId}`, { method: "DELETE" });
      return response.ok || response.status === 404;
    }
    if (item.op === "update") {
      const response = await fetch(`${remote}/api/${path}/${item.localId}`, { method: "PUT", headers: json, body: JSON.stringify(item.body) });
      return response.ok || response.status === 404;
    }
    const response = await fetch(`${remote}/api/${path}`, { method: "POST", headers: json, body: JSON.stringify(item.body) });
    return response.ok || response.status === 404;
  }
  if (item.kind === "work") {
    const body = {
      ...item.body,
      classIds: (item.body.classIds || []).map((id) => mapped("class", Number(id))),
      teacherIds: (item.body.teacherIds || (item.body.teacherId ? [item.body.teacherId] : [])).map((id) => mapped("teacher", Number(id))),
      teacherId: item.body.teacherId ? mapped("teacher", Number(item.body.teacherId)) : null,
    };
    if (body.teacherIds.length) body.teacherId = body.teacherIds[0];
    body.note = noteForSync(body.note, body.teacherIds);
    if (item.op === "delete") {
      const id = mapped("work", item.localId);
      const response = await fetch(`${remote}/api/works/${id}`, { method: "DELETE" });
      return response.ok || response.status === 404;
    }
    if (item.op === "update") {
      const id = mapped("work", item.localId);
      const response = await fetch(`${remote}/api/works/${id}`, { method: "PUT", headers: json, body: JSON.stringify(body) });
      return response.ok;
    }
    const response = await fetch(`${remote}/api/works`, { method: "POST", headers: json, body: JSON.stringify(body) });
    if (!response.ok) return false;
    ids.work[item.localId] = (await response.json()).id;
    return true;
  }
  const teacherId = item.body?.teacherId ? mapped("teacher", Number(item.body.teacherId)) : null;
  const teacherIds = Array.isArray(item.body?.teacherIds)
    ? item.body.teacherIds.map((id) => mapped("teacher", Number(id)))
    : (teacherId ? [teacherId] : []);
  const classIds = Array.isArray(item.body?.classIds)
    ? item.body.classIds.map((id) => mapped("class", Number(id)))
    : [];
  const body = { ...item.body, teacherId: teacherIds[0] || null, teacherIds, classIds };
  body.note = noteForSync(body.note, teacherIds);
  if (item.op === "create") {
    const response = await fetch(`${remote}/api/events`, {
      method: "POST",
      headers: json,
      body: JSON.stringify(body),
    });
    if (!response.ok) return false;
    ids.event[item.localId] = (await response.json()).id;
    return true;
  }
  const id = mapped("event", item.localId);
  if (item.op === "delete") {
    const response = await fetch(`${remote}/api/events/${id}`, { method: "DELETE" });
    return response.ok || response.status === 404;
  }
  const response = await fetch(`${remote}/api/events/${id}`, {
    method: "PUT",
    headers: json,
    body: JSON.stringify(body),
  });
  return response.ok;
}

let syncing = null;

async function syncRemote() {
  if (!isDesktop) return syncStatus(true, 0);
  if (!syncing) {
    syncing = runSync().finally(() => {
      syncing = null;
    });
  }
  return syncing;
}

async function runSync() {
  const remote = readConnection().server;
  const queued = readOutbox();
  if (!remote) return syncStatus(false, queued.length);
  try {
    const health = await fetch(`${remote}/api/health`, { signal: AbortSignal.timeout(4000) });
    if (!health.ok) return syncStatus(false, queued.length);
  } catch {
    return syncStatus(false, queued.length);
  }
  const folded = foldOutbox(queued);
  const ids = { teacher: {}, class: {}, event: {}, work: {} };
  const left = [];
  for (let index = 0; index < folded.length; index += 1) {
    try {
      const sent = await pushChange(remote, folded[index], ids);
      if (!sent) {
        left.push(...folded.slice(index));
        break;
      }
    } catch {
      left.push(...folded.slice(index));
      break;
    }
  }
  writeOutbox(left);
  if (left.length) return syncStatus(true, left.length);
  try {
    const response = await fetch(`${remote}/api/snapshot`, { signal: AbortSignal.timeout(8000) });
    if (response.ok) {
      const fresh = await response.json();
      applySnapshot(fresh);
    }
  } catch {
    return syncStatus(true, 0);
  }
  return syncStatus(true, 0);
}

function parseClassName(value) {
  const name = String(value || "").trim().toUpperCase();
  const match = name.match(/^(\d+)([А-ЯЁ])$/);
  if (!match) return null;
  return { name, grade: Number(match[1]), letter: match[2] };
}

async function saveNamed(table, kind, body, id) {
  const name = String(body.name || "").trim();
  if (!name) return { error: "Нужно название" };
  if (id) {
    db.prepare(`UPDATE ${table} SET name = ? WHERE id = ?`).run(name, id);
    noteChange({ kind, op: "update", localId: id, body: { name } });
    await syncRemote();
    return { id, name };
  }
  const info = db.prepare(`INSERT INTO ${table} (name) VALUES (?)`).run(name);
  const localId = Number(info.lastInsertRowid);
  noteChange({ kind, op: "create", localId, body: { name } });
  await syncRemote();
  return { id: localId, name };
}

function readConnection() {
  try {
    const saved = JSON.parse(fs.readFileSync(connectionFile, "utf8"));
    return {
      server: String(saved.server || "").replace(/\/$/, ""),
      writable: saved.writable !== false,
    };
  } catch {
    return { server: defaultServer, writable: true };
  }
}

const licenseFile = path.join(dataDir, "license.json");
const licenseProduct = "kalendar";
const builtInKey = "KALENDAR-7526-A42B-5F07";
const licenseGraceMs = 30 * 24 * 60 * 60 * 1000;

function readLicenseFile() {
  try {
    return JSON.parse(fs.readFileSync(licenseFile, "utf8"));
  } catch {
    return {};
  }
}

function writeLicenseFile(data) {
  fs.writeFileSync(licenseFile, JSON.stringify(data, null, 2));
}

function machineFingerprint() {
  const saved = readLicenseFile();
  if (String(saved.fingerprint || "").length >= 40) return saved.fingerprint;
  const fingerprint = crypto.randomBytes(32).toString("hex");
  writeLicenseFile({ ...saved, fingerprint });
  return fingerprint;
}

function protectionOff(data) {
  return data.protection === false || data.enforcement === false || data.status === "off" || data.status === "disabled";
}

function interpretLicense(data, hasKey) {
  const error = String(data.error || "");
  if (protectionOff(data)) return { state: "off" };
  if (/неизвестная программа/i.test(error)) return { state: "pending" };
  if (data.ok === true || ["ok", "active", "valid"].includes(data.status)) return { state: "ok" };
  if (!hasKey || /нужны ключ/i.test(error)) {
    return { state: "need_key", error: "Введите ключ. Один ключ — на школу, число компьютеров задаётся в кабинете лицензий." };
  }
  return { state: "denied", error: error || "Ключ не подходит" };
}

async function askLicense(action, key) {
  const response = await fetch(`https://proxip.ru/api/license/${action}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      product: licenseProduct,
      key: key || "",
      fingerprint: machineFingerprint(),
      hostName: os.hostname(),
      appVersion: "1",
    }),
  });
  const data = await response.json().catch(() => ({}));
  return data;
}

function finishLicense(saved, view) {
  if (view.state === "ok" || view.state === "off") {
    writeLicenseFile({ ...saved, lastOk: Date.now(), lastState: view.state });
  }
  return view;
}

async function currentLicense() {
  const saved = readLicenseFile();
  const key = builtInKey;
  try {
    let data = await askLicense("check", key);
    let view = interpretLicense(data, true);
    if (view.state === "denied" && /не активирован/i.test(view.error || "")) {
      data = await askLicense("activate", key);
      view = interpretLicense(data, true);
    }
    writeLicenseFile({ ...saved, fingerprint: machineFingerprint(), key, lastOk: Date.now(), lastState: view.state });
    if (view.state === "denied") {
      return { state: "denied", error: view.error || "Сервер лицензий остановил программу." };
    }
    return { state: "ok" };
  } catch {
    const since = saved.lastOk || Date.now();
    if (!saved.lastOk) {
      writeLicenseFile({ ...saved, fingerprint: machineFingerprint(), key, lastOk: since, lastState: "ok" });
    }
    if (Date.now() - since > licenseGraceMs) {
      return { state: "expired", error: "Нет интернета больше 30 дней. Подключите сеть и откройте программу снова." };
    }
    return { state: "ok" };
  }
}

async function activateLicense(key) {
  const saved = readLicenseFile();
  if (!key) return { state: "need_key", error: "Введите ключ." };
  try {
    const activated = await askLicense("activate", key);
    const view = interpretLicense(activated, true);
    if (view.state === "denied") return view;
    writeLicenseFile({ ...saved, fingerprint: machineFingerprint(), key });
    return currentLicense();
  } catch {
    return { state: "offline", error: "Нет связи с сервером лицензий. Проверьте интернет и нажмите «Повторить»." };
  }
}

const dbFile = path.join(dataDir, "school.db");
let db = new DatabaseSync(dbFile);
db.exec(`
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
  CREATE TABLE IF NOT EXISTS teachers (
    id INTEGER PRIMARY KEY,
    last_name TEXT NOT NULL,
    first_name TEXT NOT NULL,
    patronymic TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS classes (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    grade INTEGER NOT NULL,
    letter TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
  );
  CREATE TABLE IF NOT EXISTS kinds (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
  );
  CREATE TABLE IF NOT EXISTS periods (
    id INTEGER PRIMARY KEY,
    type TEXT NOT NULL,
    name TEXT NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT,
    start_time TEXT,
    end_time TEXT,
    audience TEXT,
    note TEXT,
    teacher_id INTEGER REFERENCES teachers(id)
  );
  CREATE TABLE IF NOT EXISTS works (
    id INTEGER PRIMARY KEY,
    work_date TEXT NOT NULL,
    start_time TEXT,
    end_time TEXT,
    subject_id INTEGER REFERENCES subjects(id),
    kind_id INTEGER REFERENCES kinds(id),
    raw_classes TEXT,
    note TEXT,
    teacher_id INTEGER REFERENCES teachers(id)
  );
  CREATE TABLE IF NOT EXISTS work_classes (
    work_id INTEGER NOT NULL,
    class_id INTEGER NOT NULL,
    PRIMARY KEY (work_id, class_id)
  );
  CREATE TABLE IF NOT EXISTS event_teachers (
    event_id INTEGER NOT NULL,
    teacher_id INTEGER NOT NULL,
    PRIMARY KEY (event_id, teacher_id)
  );
  CREATE TABLE IF NOT EXISTS work_teachers (
    work_id INTEGER NOT NULL,
    teacher_id INTEGER NOT NULL,
    PRIMARY KEY (work_id, teacher_id)
  );
  CREATE TABLE IF NOT EXISTS event_classes (
    event_id INTEGER NOT NULL,
    class_id INTEGER NOT NULL,
    PRIMARY KEY (event_id, class_id)
  );
`);
db.exec("DROP TABLE IF EXISTS day_notes");
const workColumns = db.prepare("PRAGMA table_info(works)").all().map((column) => column.name);
if (!workColumns.includes("teacher_id")) db.exec("ALTER TABLE works ADD COLUMN teacher_id INTEGER");
if (!workColumns.includes("all_day")) db.exec("ALTER TABLE works ADD COLUMN all_day INTEGER DEFAULT 0");
const eventColumns = db.prepare("PRAGMA table_info(events)").all().map((column) => column.name);
if (!eventColumns.includes("all_day")) db.exec("ALTER TABLE events ADD COLUMN all_day INTEGER DEFAULT 0");
db.exec(`
  CREATE TABLE IF NOT EXISTS event_kinds (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
  );
`);
if (!eventColumns.includes("kind_id")) db.exec("ALTER TABLE events ADD COLUMN kind_id INTEGER");
db.exec(`
  INSERT OR IGNORE INTO event_teachers (event_id, teacher_id)
  SELECT id, teacher_id FROM events WHERE teacher_id IS NOT NULL;
  INSERT OR IGNORE INTO work_teachers (work_id, teacher_id)
  SELECT id, teacher_id FROM works WHERE teacher_id IS NOT NULL;
`);
seed(db);
queueSharedTeachers();
ensureDailyBackup();
setInterval(ensureDailyBackup, 30 * 60 * 1000);

const weekdays = ["воскресенье", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота"];
const weekdaysShort = ["вс", "пн", "вт", "ср", "чт", "пт", "сб"];
const months = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"];

function parseDate(value) {
  const [year, month, day] = value.split("-").map(Number);
  return new Date(year, month - 1, day);
}

function formatDate(date) {
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}

function addDays(value, count) {
  const date = parseDate(value);
  date.setDate(date.getDate() + count);
  return formatDate(date);
}

function mondayOf(value) {
  const date = parseDate(value);
  const shift = (date.getDay() + 6) % 7;
  date.setDate(date.getDate() - shift);
  return formatDate(date);
}

function fullDate(value) {
  const date = parseDate(value);
  const name = weekdays[date.getDay()];
  return `${name[0].toUpperCase()}${name.slice(1)}, ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
}

function shortDate(value) {
  const date = parseDate(value);
  const name = weekdays[date.getDay()];
  return `${name[0].toUpperCase()}${name.slice(1)}, ${date.getDate()}`;
}

function teacherName(row) {
  return [row.last_name, row.first_name, row.patronymic].filter(Boolean).join(" ");
}

function covers(row, date) {
  const end = row.end_date || row.start_date;
  return date >= row.start_date && date <= end;
}

function overlaps(start, end, otherStart, otherEnd) {
  const finish = end || start;
  const otherFinish = otherEnd || otherStart;
  return start < otherFinish && otherStart < finish;
}

function workRows(from, to) {
  return db.prepare(`
    SELECT w.id, w.work_date, w.start_time, w.end_time, w.note, w.raw_classes, w.teacher_id, w.all_day,
           s.name AS subject, k.name AS kind,
           t.last_name, t.first_name, t.patronymic,
           GROUP_CONCAT(c.name, ' · ') AS classes,
           GROUP_CONCAT(c.id) AS class_ids
    FROM works w
    LEFT JOIN subjects s ON s.id = w.subject_id
    LEFT JOIN kinds k ON k.id = w.kind_id
    LEFT JOIN teachers t ON t.id = w.teacher_id
    LEFT JOIN work_classes wc ON wc.work_id = w.id
    LEFT JOIN classes c ON c.id = wc.class_id
    WHERE w.work_date >= ? AND w.work_date <= ?
    GROUP BY w.id
    ORDER BY w.work_date, w.start_time, w.id
  `).all(from, to);
}

function eventRows(from, to) {
  return db.prepare(`
    SELECT e.*, t.last_name, t.first_name, t.patronymic, ek.name AS kind_name
    FROM events e
    LEFT JOIN teachers t ON t.id = e.teacher_id
    LEFT JOIN event_kinds ek ON ek.id = e.kind_id
    WHERE e.start_date <= ? AND COALESCE(e.end_date, e.start_date) >= ?
    ORDER BY e.start_date, e.start_time, e.id
  `).all(to, from);
}

function teachersOfEvent(eventId) {
  return db.prepare(`
    SELECT t.id, t.last_name, t.first_name, t.patronymic
    FROM event_teachers et
    JOIN teachers t ON t.id = et.teacher_id
    WHERE et.event_id = ?
    ORDER BY t.last_name, t.first_name
  `).all(eventId);
}

function teachersOfWork(workId) {
  return db.prepare(`
    SELECT t.id, t.last_name, t.first_name, t.patronymic
    FROM work_teachers wt
    JOIN teachers t ON t.id = wt.teacher_id
    WHERE wt.work_id = ?
    ORDER BY t.last_name, t.first_name
  `).all(workId);
}

function classesOfEvent(eventId) {
  return db.prepare(`
    SELECT c.id, c.name
    FROM event_classes ec
    JOIN classes c ON c.id = ec.class_id
    WHERE ec.event_id = ?
    ORDER BY c.grade, c.letter
  `).all(eventId);
}

function teacherIdsOf(row, type) {
  const linked = type === "work" ? teachersOfWork(row.id) : teachersOfEvent(row.id);
  if (linked.length) return linked.map((item) => item.id);
  const fromNote = teacherIdsFromNote(row.note);
  if (fromNote.length) return fromNote;
  return row.teacher_id ? [row.teacher_id] : [];
}

function teacherNamesOf(row, type) {
  const linked = type === "work" ? teachersOfWork(row.id) : teachersOfEvent(row.id);
  if (linked.length) return linked.map(teacherName).join(", ");
  const fromNote = teacherIdsFromNote(row.note);
  if (fromNote.length) {
    const rows = db.prepare(
      `SELECT id, last_name, first_name, patronymic FROM teachers WHERE id IN (${fromNote.map(() => "?").join(",")})`,
    ).all(...fromNote);
    const byId = new Map(rows.map((item) => [item.id, teacherName(item)]));
    const names = fromNote.map((id) => byId.get(id)).filter(Boolean);
    if (names.length) return names.join(", ");
  }
  return row.last_name ? teacherName(row) : "";
}

function foldSearch(value) {
  return String(value || "").toLowerCase().replace(/ё/g, "е");
}

function searchHits(query) {
  const needle = foldSearch(query).trim();
  if (!needle) return [];
  const hits = [];
  for (const event of eventRows("2000-01-01", "2100-01-01")) {
    const teacher = teacherNamesOf(event, "event");
    const classes = classesOfEvent(event.id).map((item) => item.name).join(" ");
    const hay = foldSearch([event.title, teacher, classes, event.audience, event.kind_name].join(" "));
    if (!hay.includes(needle)) continue;
    hits.push({
      type: "event",
      id: event.id,
      date: event.start_date,
      when: fullDate(event.start_date),
      title: event.title,
      teacher,
      kind: "Мероприятие",
    });
  }
  for (const work of workRows("2000-01-01", "2100-01-01")) {
    const teacher = teacherNamesOf(work, "work");
    const hay = foldSearch([work.subject, teacher, work.classes, work.raw_classes, work.kind].join(" "));
    if (!hay.includes(needle)) continue;
    hits.push({
      type: "work",
      id: work.id,
      date: work.work_date,
      when: fullDate(work.work_date),
      title: work.subject,
      teacher,
      kind: "Контрольная",
    });
  }
  hits.sort((left, right) => right.date.localeCompare(left.date) || left.title.localeCompare(right.title, "ru"));
  return hits.slice(0, 40);
}

function teacherState(teacher, date, start, end) {
  const events = eventRows(date, date)
    .filter((event) => covers(event, date) && teacherIdsOf(event, "event").includes(teacher.id))
    .map((event) => ({
      id: event.id,
      source: "event",
      title: event.title,
      start_time: event.all_day ? null : event.start_time,
      end_time: event.all_day ? null : event.end_time,
      all_day: Boolean(event.all_day),
    }));
  const works = workRows(date, date)
    .filter((work) => teacherIdsOf(work, "work").includes(teacher.id))
    .map((work) => ({
      id: work.id,
      source: "work",
      title: work.subject,
      start_time: work.all_day ? null : work.start_time,
      end_time: work.all_day ? null : work.end_time,
      all_day: Boolean(work.all_day),
    }));
  const mine = [...events, ...works];
  if (!mine.length) return { state: "free" };
  const timed = mine.filter((item) => item.start_time);
  const untimed = mine.filter((item) => !item.start_time);
  const busy = (item) => ({
    state: "busy",
    eventId: item.id,
    source: item.source,
    title: item.title,
    label: item.all_day ? "весь день" : timeLabel(item),
  });
  const open = (item) => ({ state: "untimed", eventId: item.id, source: item.source, title: item.title });
  if (start) {
    const clash = timed.find((item) => overlaps(start, end, item.start_time, item.end_time));
    if (clash) return busy(clash);
    if (untimed.length) return open(untimed[0]);
    return { state: "free" };
  }
  if (timed.length) return busy(timed[0]);
  if (untimed.some((item) => item.all_day)) return busy(untimed.find((item) => item.all_day));
  return open(untimed[0]);
}

function timeLabel(event) {
  if (event.all_day) return "весь день";
  if (!event.start_time) return "время не указано";
  return event.end_time ? `${event.start_time}–${event.end_time}` : event.start_time;
}

function teachersFor(date, start, end) {
  return db.prepare("SELECT * FROM teachers ORDER BY last_name, first_name").all().map((teacher) => {
    const status = teacherState(teacher, date, start, end);
    return { id: teacher.id, name: teacherName(teacher), lastName: teacher.last_name, firstName: teacher.first_name, patronymic: teacher.patronymic, ...status };
  });
}

function dutyBits(row, type = "event") {
  const who = teacherNamesOf(row, type);
  const time = row.all_day ? "весь день" : row.start_time ? timeLabel(row) : "";
  return [
    who ? { text: who, kind: "" } : null,
    time ? { text: time, kind: "" } : null,
  ].filter(Boolean);
}

function lineFrom(bits) {
  return { sub: bits.map((bit) => bit.text).join(" · "), bits };
}

function dayItems(events, works) {
  return [
    ...events.map((event) => ({
      kind: "event",
      title: event.title,
      time: event.all_day ? "весь день" : event.start_time ? timeLabel(event) : "",
    })),
    ...works.map((work) => ({
      kind: "test",
      title: work.subject,
      time: work.all_day ? "весь день" : work.start_time ? timeLabel(work) : "",
    })),
  ];
}

function dayLine(events, works) {
  const items = dayItems(events, works);
  const marks = [];
  if (events.length) marks.push("event");
  if (works.length) marks.push("test");
  if (!items.length) return { marks: [], line: "Пока пусто", sub: "", bits: [], items: [] };
  return {
    marks,
    line: items.map((item) => item.title).join(", "),
    items,
    sub: "",
    bits: [],
  };
}

function normalizeTeacherIds(body) {
  if (Array.isArray(body.teacherIds) && body.teacherIds.length) {
    return [...new Set(body.teacherIds.map(Number).filter(Boolean))];
  }
  if (body.teacherId) return [Number(body.teacherId)].filter(Boolean);
  return [];
}

function normalizeClassIds(body) {
  return Array.isArray(body.classIds) ? [...new Set(body.classIds.map(Number).filter(Boolean))] : [];
}

function setEventTeachers(eventId, teacherIds) {
  db.prepare("DELETE FROM event_teachers WHERE event_id = ?").run(eventId);
  const insert = db.prepare("INSERT OR IGNORE INTO event_teachers (event_id, teacher_id) VALUES (?, ?)");
  for (const teacherId of teacherIds) insert.run(eventId, teacherId);
  db.prepare("UPDATE events SET teacher_id = ? WHERE id = ?").run(teacherIds[0] || null, eventId);
}

function setWorkTeachers(workId, teacherIds) {
  db.prepare("DELETE FROM work_teachers WHERE work_id = ?").run(workId);
  const insert = db.prepare("INSERT OR IGNORE INTO work_teachers (work_id, teacher_id) VALUES (?, ?)");
  for (const teacherId of teacherIds) insert.run(workId, teacherId);
  db.prepare("UPDATE works SET teacher_id = ? WHERE id = ?").run(teacherIds[0] || null, workId);
}

function queueSharedTeachers() {
  if (!isDesktop) return;
  try {
    const pending = new Set(readOutbox().map((item) => `${item.kind}:${item.localId}`));
    const events = db.prepare(`
      SELECT e.id, e.title, e.start_date, e.end_date, e.start_time, e.end_time, e.audience, e.note, e.all_day, e.kind_id
      FROM events e
      JOIN event_teachers et ON et.event_id = e.id
      GROUP BY e.id
      HAVING COUNT(*) > 1
    `).all();
    for (const event of events) {
      if (pending.has(`event:${event.id}`)) continue;
      const teacherIds = db.prepare("SELECT teacher_id FROM event_teachers WHERE event_id = ?").all(event.id).map((row) => row.teacher_id);
      const classIds = db.prepare("SELECT class_id FROM event_classes WHERE event_id = ?").all(event.id).map((row) => row.class_id);
      noteChange({
        kind: "event",
        op: "update",
        localId: event.id,
        body: {
          title: event.title,
          date: event.start_date,
          endDate: event.end_date || "",
          start: event.start_time || "",
          end: event.end_time || "",
          allDay: Boolean(event.all_day),
          note: noteWithoutTeachers(event.note || ""),
          teacherIds,
          teacherId: teacherIds[0] || null,
          classIds,
          audience: event.audience || "",
          wholeSchool: event.audience === "вся школа",
          eventKindId: event.kind_id || null,
        },
      });
    }
  } catch (error) {
    console.error(error);
  }
}

function setEventClasses(eventId, classIds) {
  db.prepare("DELETE FROM event_classes WHERE event_id = ?").run(eventId);
  const insert = db.prepare("INSERT OR IGNORE INTO event_classes (event_id, class_id) VALUES (?, ?)");
  for (const classId of classIds) insert.run(eventId, classId);
}

function audienceValue(body, classIds) {
  if (body.audience === "вся школа" || body.wholeSchool) return "вся школа";
  if (classIds.length) return classIds.map((id) => db.prepare("SELECT name FROM classes WHERE id = ?").get(id)?.name).filter(Boolean).join(" · ");
  return String(body.audience || "").trim();
}

function weekPayload(focus) {
  const today = formatDate(new Date());
  const start = mondayOf(focus);
  const days = [];
  for (let index = 0; index < 7; index += 1) {
    const date = addDays(start, index);
    const events = eventRows(date, date).filter((event) => covers(event, date));
    const works = workRows(date, date);
    const parsed = parseDate(date);
    days.push({
      date,
      dow: weekdaysShort[parsed.getDay()],
      dayNum: parsed.getDate(),
      ...dayLine(events, works),
    });
  }

  const focusEvents = eventRows(focus, focus).filter((event) => covers(event, focus));
  const focusWorks = workRows(focus, focus);
  const periods = db.prepare(
    "SELECT type, name FROM periods WHERE type != 'module' AND start_date <= ? AND end_date >= ? ORDER BY CASE type WHEN 'trimester' THEN 1 ELSE 2 END",
  ).all(focus, focus);

  const horizon = addDays(today, 35);
  const gap = (row, type) => {
    const date = type === "work" ? row.work_date : row.start_date;
    const title = type === "work" ? row.subject : row.title;
    const teacherIds = teacherIdsOf(row, type);
    const who = teacherNamesOf(row, type);
    const hasTime = Boolean(row.all_day || row.start_time);
    const classIds = type === "work"
      ? (row.class_ids ? String(row.class_ids).split(",").map(Number) : [])
      : classesOfEvent(row.id).map((item) => item.id);
    return {
      id: row.id,
      type,
      date,
      endDate: row.end_date || "",
      start: row.all_day ? "" : row.start_time || "",
      end: row.all_day ? "" : row.end_time || "",
      allDay: Boolean(row.all_day),
      title,
      label: type === "work" ? `Контрольная · ${title}` : title,
      audience: type === "work"
        ? (row.classes || "")
        : (row.audience || classesOfEvent(row.id).map((item) => item.name).join(" · ") || ""),
      note: row.note || "",
      teacherId: teacherIds[0] || "",
      teacherIds,
      teacher: who,
      detail: type === "work" ? row.kind || "" : "",
      classIds,
      when: date.slice(8, 10) + "." + date.slice(5, 7),
      bits: [
        !teacherIds.length ? { text: "Ответственный не назначен", kind: "who" } : null,
        !hasTime ? { text: "Время не назначено", kind: "time" } : null,
      ].filter(Boolean),
      why: [
        !teacherIds.length ? "Ответственный не назначен" : "",
        !hasTime ? "Время не назначено" : "",
      ].filter(Boolean).join(" · "),
    };
  };
  const todo = [
    ...eventRows(today, horizon)
      .filter((event) => (!event.all_day && !event.start_time) || !teacherIdsOf(event, "event").length)
      .map((event) => gap(event, "event")),
    ...workRows(today, horizon)
      .filter((work) => (!work.all_day && !work.start_time) || !teacherIdsOf(work, "work").length)
      .map((work) => gap(work, "work")),
  ].sort((left, right) => left.date.localeCompare(right.date) || left.title.localeCompare(right.title, "ru")).slice(0, 16);

  const clashDays = [];
  for (let cursor = today; cursor <= horizon; cursor = addDays(cursor, 1)) {
    const events = eventRows(cursor, cursor).filter((event) => covers(event, cursor));
    const works = workRows(cursor, cursor);
    if (events.length && works.length) {
      clashDays.push({
        date: cursor,
        when: cursor.slice(8, 10) + "." + cursor.slice(5, 7),
        title: events[0].title,
        eventTitle: events[0].title,
        workTitle: works[0].subject,
        workMeta: works[0].classes || works[0].raw_classes || "",
        why: `${works[0].subject} · ${works[0].classes || works[0].raw_classes || ""}`.trim(),
      });
    }
    if (clashDays.length === 6) break;
  }

  const end = addDays(start, 6);
  const startDate = parseDate(start);
  const endDate = parseDate(end);
  const weekLabel = startDate.getMonth() === endDate.getMonth()
    ? `неделя ${startDate.getDate()}–${endDate.getDate()} ${months[startDate.getMonth()]}`
    : `неделя ${startDate.getDate()} ${months[startDate.getMonth()]} – ${endDate.getDate()} ${months[endDate.getMonth()]}`;

  return {
    today,
    focus,
    weekStart: start,
    weekLabel,
    full: fullDate(focus),
    hero: shortDate(focus),
    isToday: focus === today,
    periods,
    days,
    events: focusEvents.map(presentEvent),
    works: focusWorks.map(presentWork),
    teachers: teachersFor(focus),
    todo,
    clashes: clashDays,
  };
}

function presentEvent(event) {
  const teachers = teachersOfEvent(event.id);
  const teacherIds = teachers.length ? teachers.map((item) => item.id) : (event.teacher_id ? [event.teacher_id] : []);
  const classes = classesOfEvent(event.id);
  return {
    id: event.id,
    type: "event",
    title: event.title,
    date: event.start_date,
    endDate: event.end_date,
    start: event.all_day ? "" : event.start_time,
    end: event.all_day ? "" : event.end_time,
    allDay: Boolean(event.all_day),
    audience: event.audience === "вся школа" ? "вся школа" : (classes.map((item) => item.name).join(" · ") || event.audience || ""),
    note: noteWithoutTeachers(event.note || ""),
    teacherId: teacherIds[0] || "",
    teacherIds,
    teacher: teachers.length ? teachers.map(teacherName).join(", ") : (event.last_name ? teacherName(event) : ""),
    classIds: classes.map((item) => item.id),
    kindId: event.kind_id || "",
    kindName: event.kind_name || "",
  };
}

function presentWork(work) {
  const teachers = teachersOfWork(work.id);
  const teacherIds = teachers.length ? teachers.map((item) => item.id) : (work.teacher_id ? [work.teacher_id] : []);
  return {
    id: work.id,
    type: "work",
    title: work.subject,
    date: work.work_date,
    start: work.all_day ? "" : work.start_time,
    end: work.all_day ? "" : work.end_time,
    allDay: Boolean(work.all_day),
    meta: work.classes || "",
    detail: work.kind,
    note: noteWithoutTeachers(work.note || ""),
    classIds: work.class_ids ? String(work.class_ids).split(",").map(Number) : [],
    teacherId: teacherIds[0] || "",
    teacherIds,
    teacher: teachers.length ? teachers.map(teacherName).join(", ") : (work.last_name ? teacherName(work) : ""),
  };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (chunk) => chunks.push(chunk));
    req.on("end", () => {
      if (!chunks.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      } catch (error) {
        reject(error);
      }
    });
  });
}

const cors = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, POST, PUT, DELETE, OPTIONS",
  "access-control-allow-headers": "content-type",
};

function send(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    ...cors,
  });
  res.end(body);
}

function dayCells(from, to) {
  const days = [];
  for (let cursor = from; cursor <= to; cursor = addDays(cursor, 1)) {
    const events = eventRows(cursor, cursor).filter((event) => covers(event, cursor));
    const works = workRows(cursor, cursor);
    const parsed = parseDate(cursor);
    days.push({
      date: cursor,
      dow: weekdaysShort[parsed.getDay()],
      dayNum: parsed.getDate(),
      ...dayLine(events, works),
    });
  }
  return days;
}

function monthsOf(from, to) {
  const result = [];
  let monthStart = `${from.slice(0, 8)}01`;
  while (monthStart <= to) {
    const date = parseDate(monthStart);
    const monthEnd = formatDate(new Date(date.getFullYear(), date.getMonth() + 1, 0));
    const sliceFrom = monthStart < from ? from : monthStart;
    const sliceTo = monthEnd > to ? to : monthEnd;
    result.push({
      label: `${months[date.getMonth()]} ${date.getFullYear()}`,
      offset: (parseDate(sliceFrom).getDay() + 6) % 7,
      days: dayCells(sliceFrom, sliceTo),
    });
    monthStart = formatDate(new Date(date.getFullYear(), date.getMonth() + 1, 1));
  }
  return result;
}

function addYears(iso, count) {
  const date = parseDate(iso);
  date.setFullYear(date.getFullYear() + count);
  return formatDate(date);
}

function boardPayload(view, focus) {
  if (view === "month") {
    const date = parseDate(focus);
    const start = formatDate(new Date(date.getFullYear(), date.getMonth(), 1));
    const end = formatDate(new Date(date.getFullYear(), date.getMonth() + 1, 0));
    return {
      view,
      label: `${months[date.getMonth()]} ${date.getFullYear()}`,
      start,
      end,
      prev: formatDate(new Date(date.getFullYear(), date.getMonth() - 1, 1)),
      next: formatDate(new Date(date.getFullYear(), date.getMonth() + 1, 1)),
      months: monthsOf(start, end),
    };
  }
  if (view === "semester") {
    const all = db.prepare("SELECT name, start_date, end_date FROM periods WHERE type = 'semester' ORDER BY start_date").all();
    let index = all.findIndex((row) => focus >= row.start_date && focus <= row.end_date);
    if (index < 0) index = 0;
    const row = all[index];
    if (!row) return { view, label: "Семестр не задан", start: focus, end: focus, prev: null, next: null, months: [] };
    return {
      view,
      label: row.name,
      start: row.start_date,
      end: row.end_date,
      prev: all[index - 1]?.start_date || null,
      next: all[index + 1]?.start_date || null,
      months: monthsOf(row.start_date, row.end_date),
    };
  }
  const span = db.prepare("SELECT MIN(start_date) AS start_date, MAX(end_date) AS end_date FROM periods WHERE type = 'semester'").get();
  const baseStart = span?.start_date || `${focus.slice(0, 4)}-09-01`;
  const baseEnd = span?.end_date || addDays(baseStart, 270);
  const focusMonth = Number(focus.slice(5, 7));
  const focusYear = Number(focus.slice(0, 4));
  const schoolYear = focusMonth >= 9 ? focusYear : focusYear - 1;
  const delta = schoolYear - Number(baseStart.slice(0, 4));
  const start = addYears(baseStart, delta);
  const end = addYears(baseEnd, delta);
  return {
    view: "year",
    label: `Учебный год ${start.slice(0, 4)}–${end.slice(0, 4)}`,
    start,
    end,
    prev: addYears(start, -1),
    next: addYears(start, 1),
    months: monthsOf(start, end),
  };
}

function excelEscape(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function excelStyle(id, fill, color, size, bold) {
  return `<Style ss:ID="${id}"><Alignment ss:Vertical="Top" ss:WrapText="1"/><Font ss:FontName="Calibri" ss:Size="${size}" ss:Bold="${bold ? 1 : 0}" ss:Color="${color}"/><Interior ss:Color="${fill}" ss:Pattern="Solid"/><Borders><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E3DCD1"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E3DCD1"/><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E3DCD1"/><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E3DCD1"/></Borders></Style>`;
}

function monthGrid(month) {
  const weeks = [];
  let row = Array.from({ length: month.offset }, () => null);
  for (const day of month.days) {
    row.push(day);
    if (row.length === 7) {
      weeks.push(row);
      row = [];
    }
  }
  if (row.length) {
    while (row.length < 7) row.push(null);
    weeks.push(row);
  }
  return weeks;
}

function excelCell(day) {
  if (!day) return `<Cell ss:StyleID="empty"/>`;
  const line = day.line && day.line !== "Пока пусто" ? day.line : "";
  const text = [day.dayNum, line, day.sub].filter(Boolean).join("\n");
  const style = day.marks.includes("event") && day.marks.includes("test")
    ? "both"
    : day.marks.includes("event")
      ? "event"
      : day.marks.includes("test")
        ? "test"
        : "day";
  return `<Cell ss:StyleID="${style}"><Data ss:Type="String">${excelEscape(text)}</Data></Cell>`;
}

function excelWorkbook(board) {
  const used = new Set();
  const months = board.months.length ? board.months : [{ label: "Календарь", offset: 0, days: [] }];
  const sheets = months.map((month, index) => {
    let name = month.label.slice(0, 31);
    while (used.has(name)) name = `${month.label.slice(0, 28)} ${index + 1}`;
    used.add(name);
    const head = `<Row ss:Height="32"><Cell ss:MergeAcross="6" ss:StyleID="title"><Data ss:Type="String">${excelEscape(month.label)}</Data></Cell></Row>`;
    const dows = `<Row ss:Height="22">${["пн", "вт", "ср", "чт", "пт", "сб", "вс"].map((name) => `<Cell ss:StyleID="dow"><Data ss:Type="String">${name}</Data></Cell>`).join("")}</Row>`;
    const weeks = monthGrid(month).map((week) => `<Row ss:Height="58">${week.map(excelCell).join("")}</Row>`).join("");
    return `<Worksheet ss:Name="${excelEscape(name)}"><Table>${"<Column ss:Width=\"118\" ss:AutoFitWidth=\"0\"/>".repeat(7)}${head}${dows}${weeks}</Table></Worksheet>`;
  }).join("");
  return `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Styles>
${excelStyle("title", "#2C4A3E", "#F7F4EE", 18, true)}
${excelStyle("dow", "#F3EFE6", "#6F675F", 11, true)}
${excelStyle("day", "#FFFCF8", "#2C2824", 11, false)}
${excelStyle("event", "#F7EEE7", "#2C2824", 11, false)}
${excelStyle("test", "#E7EEF3", "#2C2824", 11, false)}
${excelStyle("both", "#FFF6E4", "#2C2824", 11, false)}
${excelStyle("empty", "#F3EFE6", "#F3EFE6", 11, false)}
</Styles>
${sheets}
</Workbook>`;
}

function monthPayload(focus) {
  const date = parseDate(focus);
  const start = formatDate(new Date(date.getFullYear(), date.getMonth(), 1));
  const end = formatDate(new Date(date.getFullYear(), date.getMonth() + 1, 0));
  const days = [];
  for (let cursor = start; cursor <= end; cursor = addDays(cursor, 1)) {
    const events = eventRows(cursor, cursor).filter((event) => covers(event, cursor));
    const works = workRows(cursor, cursor);
    days.push({ date: cursor, ...dayLine(events, works) });
  }
  return { label: `${months[date.getMonth()]} ${date.getFullYear()}`, start, days };
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (req.method === "OPTIONS") {
    res.writeHead(204, cors);
    res.end();
    return;
  }
  try {
    if (url.pathname === "/api/connection" && req.method === "GET") {
      return send(res, 200, readConnection());
    }
    if (url.pathname === "/api/connection" && req.method === "POST") {
      const body = await readBody(req);
      const current = readConnection();
      const server = body.server == null ? current.server : String(body.server || "").trim().replace(/\/$/, "");
      const writable = body.writable == null ? current.writable : Boolean(body.writable);
      const saved = { server, writable };
      fs.writeFileSync(connectionFile, JSON.stringify(saved, null, 2));
      return send(res, 200, saved);
    }
    if (url.pathname === "/api/health" && req.method === "GET") {
      return send(res, 200, { ok: true });
    }
    if (url.pathname === "/api/snapshot" && req.method === "GET") {
      return send(res, 200, snapshot());
    }
    if (url.pathname === "/api/export" && req.method === "POST") {
      const body = await readBody(req);
      const saved = saveExcelFile(body.view || "month", body.date || formatDate(new Date()), body.place, body.path);
      if (!saved) return send(res, 400, { error: "Папка не найдена" });
      return send(res, 200, saved);
    }
    if (url.pathname === "/api/pick-folder" && req.method === "POST") {
      const folder = await pickFolder();
      return send(res, 200, { folder });
    }
    if (url.pathname === "/api/open-folder" && req.method === "POST") {
      const body = await readBody(req);
      if (!openFolder(body.folder)) return send(res, 400, { error: "Папка не найдена" });
      return send(res, 200, { ok: true });
    }
    if (url.pathname === "/api/open-site" && req.method === "POST") {
      spawn("cmd", ["/c", "start", "https://proxip.ru"], { detached: true, stdio: "ignore", windowsHide: true }).unref();
      return send(res, 200, { ok: true });
    }
    if (url.pathname === "/api/update" && req.method === "GET") {
      return send(res, 200, await checkUpdate());
    }
    if (url.pathname === "/api/update/progress" && req.method === "GET") {
      return send(res, 200, updateProgress());
    }
    if (url.pathname === "/api/update/download" && req.method === "POST") {
      return send(res, 200, await startUpdateDownload());
    }
    if (url.pathname === "/api/update/apply" && req.method === "POST") {
      const result = applyUpdate();
      return send(res, result.ok ? 200 : 400, result);
    }
    if (url.pathname === "/api/version" && req.method === "GET") {
      return send(res, 200, { version: appVersion() });
    }
    if (url.pathname === "/api/backup/pick" && req.method === "POST") {
      const body = await readBody(req);
      const file = await pickFile(body.kind === "save" ? "save" : "open");
      return send(res, 200, { file });
    }
    if (url.pathname === "/api/backup/export" && req.method === "POST") {
      const body = await readBody(req);
      const file = path.resolve(String(body.path || ""));
      if (!file.toLowerCase().endsWith(".json")) return send(res, 400, { error: "Нужен файл .json" });
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, JSON.stringify(snapshot(), null, 2));
      return send(res, 200, { name: path.basename(file) });
    }
    if (url.pathname === "/api/snapshot" && req.method === "POST") {
      const data = await readBody(req);
      if (!data || !Array.isArray(data.events) || !Array.isArray(data.teachers)) {
        return send(res, 400, { error: "В файле нет календаря" });
      }
      applySnapshot(data);
      writeOutbox([]);
      return send(res, 200, { ok: true });
    }
    if (url.pathname === "/api/backup/import" && req.method === "POST") {
      const body = await readBody(req);
      const file = path.resolve(String(body.path || ""));
      if (!fs.existsSync(file)) return send(res, 400, { error: "Файл не найден" });
      let data;
      try {
        data = JSON.parse(fs.readFileSync(file, "utf8"));
      } catch {
        return send(res, 400, { error: "Это не JSON" });
      }
      if (!data || !Array.isArray(data.events) || !Array.isArray(data.teachers)) {
        return send(res, 400, { error: "В файле нет календаря" });
      }
      if (isDesktop) {
        const remote = readConnection().server;
        if (remote) {
          try {
            const response = await fetch(`${remote}/api/snapshot`, {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify(data),
              signal: AbortSignal.timeout(20000),
            });
            if (!response.ok) return send(res, 400, { error: "Сервер не принял копию. Календарь не заменён." });
          } catch {
            return send(res, 400, { error: "Нет связи с сервером. Календарь не заменён." });
          }
        }
      }
      applySnapshot(data);
      writeOutbox([]);
      return send(res, 200, { ok: true });
    }
    if (url.pathname === "/api/backups" && req.method === "GET") {
      return send(res, 200, listBackups());
    }
    if (url.pathname === "/api/backups/restore" && req.method === "POST") {
      const body = await readBody(req);
      if (!restoreBackup(String(body.name || ""))) return send(res, 400, { error: "Такой копии нет" });
      return send(res, 200, { ok: true });
    }
    if (url.pathname === "/api/sync" && req.method === "GET") {
      return send(res, 200, await syncRemote());
    }
    if (url.pathname === "/api/license" && req.method === "GET") {
      return send(res, 200, await currentLicense());
    }
    if (url.pathname === "/api/license" && req.method === "POST") {
      const body = await readBody(req);
      return send(res, 200, await activateLicense(String(body.key || "").trim()));
    }
    if (url.pathname === "/api/week" && req.method === "GET") {
      await syncRemote();
      const focus = url.searchParams.get("date") || formatDate(new Date());
      return send(res, 200, weekPayload(focus));
    }
    if (url.pathname === "/api/month" && req.method === "GET") {
      return send(res, 200, monthPayload(url.searchParams.get("date") || formatDate(new Date())));
    }
    if (url.pathname === "/api/board" && req.method === "GET") {
      await syncRemote();
      const focus = url.searchParams.get("date") || formatDate(new Date());
      const view = url.searchParams.get("view") || "month";
      return send(res, 200, boardPayload(view, focus));
    }
    if (url.pathname === "/api/search" && req.method === "GET") {
      return send(res, 200, { hits: searchHits(url.searchParams.get("q") || "") });
    }
    if (url.pathname === "/api/list" && req.method === "GET") {
      const from = url.searchParams.get("from");
      const to = url.searchParams.get("to");
      const kind = url.searchParams.get("kind");
      if (kind === "events") {
        const rows = eventRows(from, to).map((event) => ({
          date: event.start_date,
          title: event.title,
          meta: [event.start_time, event.last_name].filter(Boolean).join(" · "),
        }));
        return send(res, 200, { title: "Мероприятия", rows });
      }
      const rows = workRows(from, to).map((work) => ({
        date: work.work_date,
        title: work.subject,
        meta: [work.classes, work.kind].filter(Boolean).join(" · "),
      }));
      return send(res, 200, { title: "Контрольные", rows });
    }
    if (url.pathname === "/api/busy" && req.method === "GET") {
      const date = url.searchParams.get("date");
      return send(res, 200, { teachers: teachersFor(date, url.searchParams.get("start") || "", url.searchParams.get("end") || "") });
    }
    if (url.pathname === "/api/lookups" && req.method === "GET") {
      return send(res, 200, {
        classes: db.prepare("SELECT id, name, grade FROM classes ORDER BY grade, letter").all(),
        subjects: db.prepare("SELECT id, name FROM subjects ORDER BY name").all(),
        kinds: db.prepare("SELECT id, name FROM kinds ORDER BY name").all(),
        eventKinds: db.prepare("SELECT id, name FROM event_kinds ORDER BY name").all(),
      });
    }
    if (url.pathname === "/api/works" && req.method === "POST") {
      const body = await readBody(req);
      const subject = (body.title || "").trim();
      if (!subject || !body.date) return send(res, 400, { error: "Нужны предмет и дата" });
      let subjectId = db.prepare("SELECT id FROM subjects WHERE name = ?").get(subject)?.id;
      if (!subjectId) subjectId = Number(db.prepare("INSERT INTO subjects (name) VALUES (?)").run(subject).lastInsertRowid);
      const kindName = (body.kind || "").trim();
      let kindId = null;
      if (kindName) {
        kindId = db.prepare("SELECT id FROM kinds WHERE name = ?").get(kindName)?.id;
        if (!kindId) kindId = Number(db.prepare("INSERT INTO kinds (name) VALUES (?)").run(kindName).lastInsertRowid);
      }
      const allDay = Boolean(body.allDay);
      const teacherIds = normalizeTeacherIds(body);
      const classIds = normalizeClassIds(body);
      const info = db.prepare(`
        INSERT INTO works (work_date, start_time, end_time, subject_id, kind_id, raw_classes, note, teacher_id, all_day)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        body.date,
        allDay ? null : body.start || null,
        allDay ? null : body.end || null,
        subjectId,
        kindId,
        "",
        body.note || "",
        teacherIds[0] || null,
        allDay ? 1 : 0,
      );
      const workId = Number(info.lastInsertRowid);
      setWorkTeachers(workId, teacherIds);
      const link = db.prepare("INSERT OR IGNORE INTO work_classes (work_id, class_id) VALUES (?, ?)");
      for (const classId of classIds) link.run(workId, classId);
      noteChange({ kind: "work", op: "create", localId: workId, body: { ...body, teacherIds, classIds, allDay } });
      await syncRemote();
      return send(res, 200, { id: workId });
    }
    const workMatch = url.pathname.match(/^\/api\/works\/(\d+)$/);
    if (workMatch && (req.method === "PUT" || req.method === "DELETE")) {
      const workId = Number(workMatch[1]);
      if (req.method === "DELETE") {
        db.prepare("DELETE FROM work_classes WHERE work_id = ?").run(workId);
        db.prepare("DELETE FROM work_teachers WHERE work_id = ?").run(workId);
        db.prepare("DELETE FROM works WHERE id = ?").run(workId);
        noteChange({ kind: "work", op: "delete", localId: workId });
        await syncRemote();
        return send(res, 200, { ok: true });
      }
      const body = await readBody(req);
      const subject = (body.title || "").trim();
      if (!subject || !body.date) return send(res, 400, { error: "Нужны предмет и дата" });
      let subjectId = db.prepare("SELECT id FROM subjects WHERE name = ?").get(subject)?.id;
      if (!subjectId) subjectId = Number(db.prepare("INSERT INTO subjects (name) VALUES (?)").run(subject).lastInsertRowid);
      const kindName = (body.kind || "").trim();
      let kindId = null;
      if (kindName) {
        kindId = db.prepare("SELECT id FROM kinds WHERE name = ?").get(kindName)?.id;
        if (!kindId) kindId = Number(db.prepare("INSERT INTO kinds (name) VALUES (?)").run(kindName).lastInsertRowid);
      }
      const allDay = Boolean(body.allDay);
      const teacherIds = normalizeTeacherIds(body);
      const classIds = normalizeClassIds(body);
      db.prepare(`
        UPDATE works
        SET work_date = ?, start_time = ?, end_time = ?, subject_id = ?, kind_id = ?, note = ?, teacher_id = ?, all_day = ?
        WHERE id = ?
      `).run(
        body.date,
        allDay ? null : body.start || null,
        allDay ? null : body.end || null,
        subjectId,
        kindId,
        body.note || "",
        teacherIds[0] || null,
        allDay ? 1 : 0,
        workId,
      );
      setWorkTeachers(workId, teacherIds);
      db.prepare("DELETE FROM work_classes WHERE work_id = ?").run(workId);
      const link = db.prepare("INSERT OR IGNORE INTO work_classes (work_id, class_id) VALUES (?, ?)");
      for (const classId of classIds) link.run(workId, classId);
      noteChange({ kind: "work", op: "update", localId: workId, body: { ...body, teacherIds, classIds, allDay } });
      await syncRemote();
      return send(res, 200, { ok: true });
    }
    if (url.pathname === "/api/events" && req.method === "POST") {
      const body = await readBody(req);
      if (!body.title?.trim() || !body.date) return send(res, 400, { error: "Нужны название и дата" });
      const allDay = Boolean(body.allDay);
      const teacherIds = normalizeTeacherIds(body);
      const classIds = body.wholeSchool || body.audience === "вся школа" ? [] : normalizeClassIds(body);
      const audience = audienceValue(body, classIds);
      const kindId = body.eventKindId ? Number(body.eventKindId) : null;
      const info = db.prepare(`
        INSERT INTO events (title, start_date, end_date, start_time, end_time, audience, note, teacher_id, all_day, kind_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        body.title.trim(),
        body.date,
        body.endDate || null,
        allDay ? null : body.start || null,
        allDay ? null : body.end || null,
        audience,
        body.note || "",
        teacherIds[0] || null,
        allDay ? 1 : 0,
        kindId,
      );
      const eventId = Number(info.lastInsertRowid);
      setEventTeachers(eventId, teacherIds);
      setEventClasses(eventId, classIds);
      noteChange({ kind: "event", op: "create", localId: eventId, body: { ...body, teacherIds, classIds, allDay, audience } });
      await syncRemote();
      return send(res, 200, { id: eventId });
    }
    const eventMatch = url.pathname.match(/^\/api\/events\/(\d+)$/);
    if (eventMatch && req.method === "PUT") {
      const body = await readBody(req);
      if (!body.title?.trim() || !body.date) return send(res, 400, { error: "Нужны название и дата" });
      const eventId = Number(eventMatch[1]);
      const allDay = Boolean(body.allDay);
      const teacherIds = normalizeTeacherIds(body);
      const classIds = body.wholeSchool || body.audience === "вся школа" ? [] : normalizeClassIds(body);
      const audience = audienceValue(body, classIds);
      const kindId = body.eventKindId ? Number(body.eventKindId) : null;
      db.prepare(`
        UPDATE events
        SET title = ?, start_date = ?, end_date = ?, start_time = ?, end_time = ?, audience = ?, note = ?, teacher_id = ?, all_day = ?, kind_id = ?
        WHERE id = ?
      `).run(
        body.title.trim(),
        body.date,
        body.endDate || null,
        allDay ? null : body.start || null,
        allDay ? null : body.end || null,
        audience,
        body.note || "",
        teacherIds[0] || null,
        allDay ? 1 : 0,
        kindId,
        eventId,
      );
      setEventTeachers(eventId, teacherIds);
      setEventClasses(eventId, classIds);
      noteChange({ kind: "event", op: "update", localId: eventId, body: { ...body, teacherIds, classIds, allDay, audience } });
      await syncRemote();
      return send(res, 200, { ok: true });
    }
    if (eventMatch && req.method === "DELETE") {
      const eventId = Number(eventMatch[1]);
      db.prepare("DELETE FROM event_teachers WHERE event_id = ?").run(eventId);
      db.prepare("DELETE FROM event_classes WHERE event_id = ?").run(eventId);
      db.prepare("DELETE FROM events WHERE id = ?").run(eventId);
      noteChange({ kind: "event", op: "delete", localId: eventId });
      await syncRemote();
      return send(res, 200, { ok: true });
    }
    if (url.pathname === "/api/teachers" && req.method === "POST") {
      const body = await readBody(req);
      if (!body.lastName?.trim()) return send(res, 400, { error: "Нужна фамилия" });
      const info = db.prepare(
        "INSERT INTO teachers (last_name, first_name, patronymic) VALUES (?, ?, ?)",
      ).run(body.lastName.trim(), (body.firstName || "").trim(), (body.patronymic || "").trim());
      const teacherId = Number(info.lastInsertRowid);
      noteChange({ kind: "teacher", op: "create", localId: teacherId, body });
      await syncRemote();
      return send(res, 200, { id: teacherId });
    }
    if (url.pathname === "/api/classes" && req.method === "POST") {
      const body = await readBody(req);
      const parsed = parseClassName(body.name);
      if (!parsed) return send(res, 400, { error: "Класс пишется так: 7А" });
      const info = db.prepare("INSERT INTO classes (name, grade, letter) VALUES (?, ?, ?)").run(parsed.name, parsed.grade, parsed.letter);
      const classId = Number(info.lastInsertRowid);
      noteChange({ kind: "class", op: "create", localId: classId, body: { name: parsed.name } });
      await syncRemote();
      return send(res, 200, { id: classId, name: parsed.name });
    }
    if (url.pathname === "/api/event-kinds" && req.method === "POST") {
      const saved = await saveNamed("event_kinds", "eventKind", await readBody(req));
      if (saved.error) return send(res, 400, saved);
      return send(res, 200, saved);
    }
    if (url.pathname === "/api/kinds" && req.method === "POST") {
      const saved = await saveNamed("kinds", "workKind", await readBody(req));
      if (saved.error) return send(res, 400, saved);
      return send(res, 200, saved);
    }
    if (url.pathname === "/api/subjects" && req.method === "POST") {
      const saved = await saveNamed("subjects", "subject", await readBody(req));
      if (saved.error) return send(res, 400, saved);
      return send(res, 200, saved);
    }
    const teacherMatch = url.pathname.match(/^\/api\/teachers\/(\d+)$/);
    if (teacherMatch && req.method === "PUT") {
      const body = await readBody(req);
      if (!body.lastName?.trim()) return send(res, 400, { error: "Нужна фамилия" });
      const teacherId = Number(teacherMatch[1]);
      db.prepare("UPDATE teachers SET last_name = ?, first_name = ?, patronymic = ? WHERE id = ?").run(
        body.lastName.trim(),
        (body.firstName || "").trim(),
        (body.patronymic || "").trim(),
        teacherId,
      );
      noteChange({ kind: "teacher", op: "update", localId: teacherId, body });
      await syncRemote();
      return send(res, 200, { ok: true });
    }
    if (teacherMatch && req.method === "DELETE") {
      const teacherId = Number(teacherMatch[1]);
      db.prepare("DELETE FROM event_teachers WHERE teacher_id = ?").run(teacherId);
      db.prepare("DELETE FROM work_teachers WHERE teacher_id = ?").run(teacherId);
      db.prepare("UPDATE events SET teacher_id = NULL WHERE teacher_id = ?").run(teacherId);
      db.prepare("UPDATE works SET teacher_id = NULL WHERE teacher_id = ?").run(teacherId);
      db.prepare("DELETE FROM teachers WHERE id = ?").run(teacherId);
      noteChange({ kind: "teacher", op: "delete", localId: teacherId });
      await syncRemote();
      return send(res, 200, { ok: true });
    }
    const classMatch = url.pathname.match(/^\/api\/classes\/(\d+)$/);
    if (classMatch && req.method === "PUT") {
      const parsed = parseClassName((await readBody(req)).name);
      if (!parsed) return send(res, 400, { error: "Класс пишется так: 7А" });
      const classId = Number(classMatch[1]);
      db.prepare("UPDATE classes SET name = ?, grade = ?, letter = ? WHERE id = ?").run(parsed.name, parsed.grade, parsed.letter, classId);
      noteChange({ kind: "class", op: "update", localId: classId, body: { name: parsed.name } });
      await syncRemote();
      return send(res, 200, { id: classId, name: parsed.name });
    }
    if (classMatch && req.method === "DELETE") {
      const classId = Number(classMatch[1]);
      db.prepare("DELETE FROM work_classes WHERE class_id = ?").run(classId);
      db.prepare("DELETE FROM event_classes WHERE class_id = ?").run(classId);
      db.prepare("DELETE FROM classes WHERE id = ?").run(classId);
      noteChange({ kind: "class", op: "delete", localId: classId });
      await syncRemote();
      return send(res, 200, { ok: true });
    }
    const eventKindMatch = url.pathname.match(/^\/api\/event-kinds\/(\d+)$/);
    if (eventKindMatch && (req.method === "PUT" || req.method === "DELETE")) {
      const id = Number(eventKindMatch[1]);
      if (req.method === "DELETE") {
        db.prepare("UPDATE events SET kind_id = NULL WHERE kind_id = ?").run(id);
        db.prepare("DELETE FROM event_kinds WHERE id = ?").run(id);
        noteChange({ kind: "eventKind", op: "delete", localId: id });
        await syncRemote();
        return send(res, 200, { ok: true });
      }
      const saved = await saveNamed("event_kinds", "eventKind", await readBody(req), id);
      if (saved.error) return send(res, 400, saved);
      return send(res, 200, saved);
    }
    const subjectMatch = url.pathname.match(/^\/api\/subjects\/(\d+)$/);
    if (subjectMatch && (req.method === "PUT" || req.method === "DELETE")) {
      const id = Number(subjectMatch[1]);
      if (req.method === "DELETE") {
        db.prepare("UPDATE works SET subject_id = NULL WHERE subject_id = ?").run(id);
        db.prepare("DELETE FROM subjects WHERE id = ?").run(id);
        noteChange({ kind: "subject", op: "delete", localId: id });
        await syncRemote();
        return send(res, 200, { ok: true });
      }
      const saved = await saveNamed("subjects", "subject", await readBody(req), id);
      if (saved.error) return send(res, 400, saved);
      return send(res, 200, saved);
    }
    const kindMatch = url.pathname.match(/^\/api\/kinds\/(\d+)$/);
    if (kindMatch && (req.method === "PUT" || req.method === "DELETE")) {
      const id = Number(kindMatch[1]);
      if (req.method === "DELETE") {
        db.prepare("UPDATE works SET kind_id = NULL WHERE kind_id = ?").run(id);
        db.prepare("DELETE FROM kinds WHERE id = ?").run(id);
        noteChange({ kind: "workKind", op: "delete", localId: id });
        await syncRemote();
        return send(res, 200, { ok: true });
      }
      const saved = await saveNamed("kinds", "workKind", await readBody(req), id);
      if (saved.error) return send(res, 400, saved);
      return send(res, 200, saved);
    }

    const filePath = path.normalize(path.join(root, "public", url.pathname === "/" ? "index.html" : url.pathname));
    if (!filePath.startsWith(path.join(root, "public"))) return send(res, 404, { error: "Нет страницы" });
    if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) return send(res, 404, { error: "Нет страницы" });
    const types = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".svg": "image/svg+xml" };
    res.writeHead(200, {
      "content-type": types[path.extname(filePath)] || "application/octet-stream",
      "cache-control": "no-store",
    });
    fs.createReadStream(filePath).pipe(res);
  } catch (error) {
    send(res, 500, { error: "Не получилось обработать запрос" });
    console.error(error);
  }
});

server.listen(port, host, () => {
  console.log(`http://${host}:${port}`);
});
